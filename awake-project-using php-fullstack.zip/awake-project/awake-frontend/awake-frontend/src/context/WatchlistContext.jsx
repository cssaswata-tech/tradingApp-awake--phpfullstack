import { createContext, useContext, useEffect, useState } from "react";
import axiosClient from "../api/axiosClient";
import { SEED_STOCKS } from "../api/mockData";
import { NIFTY500_UNIQUE } from "../api/nifty500";
import { useAuth } from "./AuthContext";

const WatchlistContext = createContext(null);
const STORAGE_KEY = "awake_watchlists"; // used only as a guest (logged-out) fallback

// Backend only stores { id, symbol, exchange } per stock. Enrich with the
// display fields (name/price/change) the UI needs. SEED_STOCKS has mock
// price/change data for a handful of names; the full NIFTY500_UNIQUE list
// covers company name/exchange for any of the 500 symbols a user can add.
function enrichStock(stock) {
  const seed = SEED_STOCKS.find((s) => s.symbol === stock.symbol);
  const n500 = NIFTY500_UNIQUE.find((s) => s.symbol === stock.symbol);
  return {
    id: stock.id,
    symbol: stock.symbol,
    exchange: stock.exchange || seed?.exchange || n500?.exchange || "NSE",
    name: seed?.name || n500?.name || stock.symbol,
    price: seed?.price ?? 100,
    change: seed?.change ?? 0,
    changePct: seed?.changePct ?? 0,
  };
}

function enrichWatchlist(wl) {
  return { id: wl.id, name: wl.name, stocks: (wl.stocks || []).map(enrichStock) };
}

function loadGuest() {
  const raw = localStorage.getItem(STORAGE_KEY);
  if (raw) return JSON.parse(raw);
  return [
    { id: "wl-1", name: "First Watchlist", stocks: SEED_STOCKS.map((s, i) => ({ id: `st-${i}`, ...s })) },
  ];
}

export function WatchlistProvider({ children }) {
  const { user } = useAuth();
  const [watchlists, setWatchlists] = useState(user ? [] : loadGuest);
  const [loading, setLoading] = useState(false);

  // Logged in -> load real watchlists from Laravel.
  // Logged out -> fall back to the localStorage guest list.
  useEffect(() => {
    if (!user) {
      setWatchlists(loadGuest());
      return;
    }
    let cancelled = false;
    setLoading(true);
    axiosClient
      .get("/watchlists.php")
      .then((res) => {
        if (!cancelled) setWatchlists(res.data.map(enrichWatchlist));
      })
      .catch(() => {
        if (!cancelled) setWatchlists([]);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [user]);

  // Keep the guest list persisted; no-op (harmless) once logged in.
  useEffect(() => {
    if (!user) localStorage.setItem(STORAGE_KEY, JSON.stringify(watchlists));
  }, [watchlists, user]);

  // CREATE a watchlist
  async function createWatchlist(name) {
    if (!user) {
      const wl = { id: `wl-${Date.now()}`, name, stocks: [] };
      setWatchlists((prev) => [...prev, wl]);
      return wl;
    }
    const res = await axiosClient.post("/watchlists.php", { name });
    const wl = enrichWatchlist(res.data);
    setWatchlists((prev) => [...prev, wl]);
    return wl;
  }

  // DELETE a whole watchlist
  async function deleteWatchlist(id) {
    if (!user) {
      setWatchlists((prev) => prev.filter((w) => w.id !== id));
      return;
    }
    await axiosClient.delete(`/watchlists.php?id=${id}`);
    setWatchlists((prev) => prev.filter((w) => w.id !== id));
  }

  // CREATE (add) a stock into a watchlist
  async function addStock(watchlistId, stock) {
    if (!user) {
      setWatchlists((prev) =>
        prev.map((w) =>
          w.id === watchlistId
            ? { ...w, stocks: [...w.stocks, { id: `st-${Date.now()}`, ...stock }] }
            : w
        )
      );
      return;
    }
    const res = await axiosClient.post("/watchlist_stocks.php", {
      watchlist_id: watchlistId,
      symbol: stock.symbol,
      exchange: stock.exchange,
    });
    const saved = enrichStock(res.data);
    setWatchlists((prev) =>
      prev.map((w) => (w.id === watchlistId ? { ...w, stocks: [...w.stocks, saved] } : w))
    );
  }

  // DELETE a stock from a watchlist
  async function removeStock(watchlistId, stockId) {
    if (!user) {
      setWatchlists((prev) =>
        prev.map((w) =>
          w.id === watchlistId ? { ...w, stocks: w.stocks.filter((s) => s.id !== stockId) } : w
        )
      );
      return;
    }
    await axiosClient.delete(`/watchlist_stocks.php?id=${stockId}`);
    setWatchlists((prev) =>
      prev.map((w) =>
        w.id === watchlistId ? { ...w, stocks: w.stocks.filter((s) => s.id !== stockId) } : w
      )
    );
  }

  // READ is just watchlists state itself; clicking a stock routes to /terminal/:symbol

  return (
    <WatchlistContext.Provider
      value={{ watchlists, loading, createWatchlist, deleteWatchlist, addStock, removeStock }}
    >
      {children}
    </WatchlistContext.Provider>
  );
}

export const useWatchlist = () => useContext(WatchlistContext);

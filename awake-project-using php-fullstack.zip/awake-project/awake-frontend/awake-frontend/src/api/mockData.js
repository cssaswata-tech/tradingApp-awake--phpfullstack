// Local mock data used until the PHP backend is connected.
// Every place that uses this is written so swapping to axiosClient
// calls later is a one-line change (see comments in each file).

export const SEED_STOCKS = [
  { symbol: "URBANCO", name: "Urban Company", exchange: "NSE", price: 132.75, change: -4.22, changePct: -3.08 },
  { symbol: "DABUR", name: "Dabur India", exchange: "NSE", price: 443.5, change: 0.35, changePct: 0.08 },
  { symbol: "MAZDOCK", name: "Mazagon Dock Shipbuilders", exchange: "BSE", price: 2420.1, change: 46.55, changePct: 1.96 },
  { symbol: "PARAS", name: "Paras Defence Space Tech", exchange: "NSE", price: 1253.1, change: 36.3, changePct: 2.98 },
  { symbol: "SCI", name: "Shipping Corporation of India", exchange: "NSE", price: 284.9, change: 7.25, changePct: 2.61 },
  { symbol: "BANKBARODA", name: "Bank of Baroda", exchange: "NSE", price: 250.95, change: 6.35, changePct: 2.6 },
  { symbol: "GLENMARK", name: "Glenmark Pharmaceuticals", exchange: "NSE", price: 2282.9, change: 15.7, changePct: 0.69 },
  { symbol: "TCS", name: "Tata Consultancy Services", exchange: "NSE", price: 2069.0, change: 19.5, changePct: 0.95 },
  { symbol: "PERSISTENT", name: "Persistent Systems", exchange: "NSE", price: 5053.9, change: 224.0, changePct: 4.64 },
];

export const INDICES = [
  { symbol: "NIFTY50", name: "Nifty 50", price: 24206.9, change: 244.1, changePct: 1.02 },
  { symbol: "NIFTYNXT50", name: "Nifty Next 50", price: 72391.8, change: 905.95, changePct: 1.27 },
  { symbol: "NIFTYBANK", name: "Nifty Bank", price: 58045.9, change: 793.45, changePct: 1.39 },
  { symbol: "INDIAVIX", name: "India VIX", price: 12.25, change: -1.11, changePct: -8.31 },
  { symbol: "FINNIFTY", name: "Fin Nifty", price: 26831.05, change: 348.2, changePct: 1.32 },
];

export const MOVERS = {
  gainers: [
    { symbol: "IC ELEC", name: "IC Electricals Company", price: 174.3, change: 75.3, changePct: 76.06 },
    { symbol: "SHARDUL", name: "Shardul Securities", price: 33.6, change: 5.6, changePct: 20.0 },
    { symbol: "GOLDIAM", name: "Goldiam International", price: 378.0, change: 62.6, changePct: 19.85 },
    { symbol: "NBI", name: "NBI Industrial Finance", price: 2301.4, change: 379.8, changePct: 19.76 },
    { symbol: "PPAP", name: "PPAP Automotive", price: 323.37, change: 46.74, changePct: 16.9 },
  ],
  losers: [
    { symbol: "ZOMEDIA", name: "Zee Media Corporation", price: 12.4, change: -2.1, changePct: -14.5 },
    { symbol: "RAJTV", name: "Raj Television Network", price: 45.8, change: -6.3, changePct: -12.1 },
    { symbol: "SUZLON", name: "Suzlon Energy", price: 61.2, change: -5.9, changePct: -8.8 },
  ],
  volume: [
    { symbol: "TATASTEEL", name: "Tata Steel", price: 168.4, change: 2.1, changePct: 1.26 },
    { symbol: "IDEA", name: "Vodafone Idea", price: 8.9, change: -0.2, changePct: -2.2 },
    { symbol: "YESBANK", name: "Yes Bank", price: 21.3, change: 0.4, changePct: 1.9 },
  ],
};

export const LATEST_IPOS = [
  { name: "Solstice Renewables Ltd", type: "Mainboard", priceBand: "₹210 - ₹222", open: "2026-07-14", close: "2026-07-16", status: "upcoming" },
  { name: "Nimbus Cloud Tech", type: "SME", priceBand: "₹85 - ₹90", open: "2026-07-10", close: "2026-07-12", status: "open" },
  { name: "Kaveri Foods & Bev", type: "Mainboard", priceBand: "₹140 - ₹148", open: "2026-07-01", close: "2026-07-03", status: "listed", listingGain: "12.4%" },
  { name: "Orbit Aerospace", type: "Mainboard", priceBand: "₹560 - ₹590", open: "2026-07-20", close: "2026-07-23", status: "upcoming" },
];

export const TRENDING = [SEED_STOCKS[8], SEED_STOCKS[3], SEED_STOCKS[2]];

// "Most Traded" / "Most Bought MTF" tabs on the Home page's Trending
// Stocks card — separate representative datasets so switching tabs
// actually changes what's shown instead of repeating the same 3 stocks.
export const MOST_TRADED = [SEED_STOCKS[5], SEED_STOCKS[7], SEED_STOCKS[0], MOVERS.volume[0], MOVERS.volume[2]];
export const MOST_BOUGHT_MTF = [SEED_STOCKS[1], SEED_STOCKS[6], MOVERS.gainers[1], MOVERS.gainers[2], SEED_STOCKS[4]];

// ---- Section-specific datasets (Markets page tabs) ----
// Real free live feeds for options chains, futures OI, and Indian MF NAVs
// aren't practically available without a paid data vendor, so these use
// representative data. Equities/ETFs can be swapped to the live Twelve Data
// feed in src/api/marketApi.js by adding a VITE_TWELVEDATA_KEY.

export const ETF_LIST = [
  { symbol: "NIFTYBEES", name: "Nippon India ETF Nifty BeES", exchange: "NSE", price: 253.4, change: 2.1, changePct: 0.83 },
  { symbol: "GOLDBEES", name: "Nippon India ETF Gold BeES", exchange: "NSE", price: 68.9, change: -0.32, changePct: -0.46 },
  { symbol: "BANKBEES", name: "Nippon India ETF Bank BeES", exchange: "NSE", price: 542.1, change: 6.8, changePct: 1.27 },
  { symbol: "JUNIORBEES", name: "Nippon India ETF Junior BeES", exchange: "NSE", price: 712.3, change: 5.4, changePct: 0.76 },
  { symbol: "ITBEES", name: "Nippon India ETF IT BeES", exchange: "NSE", price: 41.2, change: -0.5, changePct: -1.2 },
  { symbol: "SILVERBEES", name: "Nippon India ETF Silver BeES", exchange: "NSE", price: 92.6, change: 1.1, changePct: 1.2 },
];

export const MF_LIST = [
  { symbol: "PPFCF", name: "Parag Parikh Flexi Cap Fund", category: "Flexi Cap", nav: 84.32, oneYearReturn: 24.6, risk: "High" },
  { symbol: "MOSFLEXI", name: "Motilal Oswal Flexi Cap Fund", category: "Flexi Cap", nav: 21.55, oneYearReturn: 18.2, risk: "High" },
  { symbol: "QNIFTY50", name: "Quant Nifty 50 Index Fund", category: "Index", nav: 32.1, oneYearReturn: 15.4, risk: "Moderate" },
  { symbol: "SBISMALL", name: "SBI Small Cap Fund", category: "Small Cap", nav: 158.7, oneYearReturn: 29.1, risk: "Very High" },
  { symbol: "HDFCHYBR", name: "HDFC Hybrid Equity Fund", category: "Hybrid", nav: 112.4, oneYearReturn: 13.8, risk: "Moderate" },
  { symbol: "ICICILIQ", name: "ICICI Prudential Liquid Fund", category: "Liquid", nav: 385.9, oneYearReturn: 7.1, risk: "Low" },
];

export const FUTURES_LIST = [
  { symbol: "NIFTY26JUL FUT", underlying: "NIFTY 50", expiry: "2026-07-30", price: 24238.5, change: 231.4, changePct: 0.96, oi: "1.2Cr", lotSize: 25 },
  { symbol: "BANKNIFTY26JUL FUT", underlying: "NIFTY BANK", expiry: "2026-07-30", price: 58015.2, change: 705.1, changePct: 1.23, oi: "42L", lotSize: 15 },
  { symbol: "RELIANCE26JUL FUT", underlying: "Reliance Industries", expiry: "2026-07-30", price: 3120.6, change: 18.4, changePct: 0.59, oi: "8.4L", lotSize: 250 },
  { symbol: "TCS26JUL FUT", underlying: "Tata Consultancy Services", expiry: "2026-07-30", price: 2074.1, change: 20.1, changePct: 0.98, oi: "3.1L", lotSize: 175 },
  { symbol: "CRUDEOIL26JUL FUT", underlying: "Crude Oil", expiry: "2026-07-18", price: 6842.0, change: -54.0, changePct: -0.78, oi: "9.8K", lotSize: 100 },
];

export const OPTIONS_UNDERLYINGS = ["NIFTY 50", "NIFTY BANK", "RELIANCE"];

export function buildOptionChain(spot) {
  const step = spot > 10000 ? 100 : spot > 1000 ? 20 : 5;
  const atmStrike = Math.round(spot / step) * step;
  const rows = [];
  for (let i = -4; i <= 4; i++) {
    const strike = atmStrike + i * step;
    const dist = Math.abs(strike - spot);
    const callLTP = Math.max(0.5, spot - strike + dist * 0.35 + Math.random() * 8);
    const putLTP = Math.max(0.5, strike - spot + dist * 0.35 + Math.random() * 8);
    rows.push({
      strike,
      callLTP: +callLTP.toFixed(2),
      callOI: Math.floor(5000 + Math.random() * 90000),
      callIV: +(12 + Math.random() * 18).toFixed(1),
      putLTP: +putLTP.toFixed(2),
      putOI: Math.floor(5000 + Math.random() * 90000),
      putIV: +(12 + Math.random() * 18).toFixed(1),
    });
  }
  return rows;
}

export const COMMODITIES_LIST = [
  { symbol: "GOLD", name: "Gold (10g)", exchange: "MCX", price: 72380, change: 210, changePct: 0.29 },
  { symbol: "SILVER", name: "Silver (1kg)", exchange: "MCX", price: 91250, change: -340, changePct: -0.37 },
  { symbol: "CRUDEOIL", name: "Crude Oil (1bbl)", exchange: "MCX", price: 6842, change: -54, changePct: -0.78 },
  { symbol: "NATURALGAS", name: "Natural Gas (1mmBtu)", exchange: "MCX", price: 246.3, change: 3.8, changePct: 1.57 },
  { symbol: "COPPER", name: "Copper (1kg)", exchange: "MCX", price: 812.4, change: 6.1, changePct: 0.76 },
  { symbol: "COTTON", name: "Cotton (1 bale)", exchange: "MCX", price: 58200, change: 420, changePct: 0.73 },
];

export const RENT_STOCKS_LIST = [
  { symbol: "TCS", name: "Tata Consultancy Services", lendingRatePct: 3.2, demandLabel: "High demand", minQty: 1 },
  { symbol: "RELIANCE", name: "Reliance Industries", lendingRatePct: 1.8, demandLabel: "Moderate demand", minQty: 1 },
  { symbol: "SUZLON", name: "Suzlon Energy", lendingRatePct: 12.4, demandLabel: "Very high demand", minQty: 50 },
  { symbol: "IDEA", name: "Vodafone Idea", lendingRatePct: 15.6, demandLabel: "Very high demand", minQty: 100 },
  { symbol: "ZOMATO", name: "Eternal (Zomato)", lendingRatePct: 6.7, demandLabel: "High demand", minQty: 10 },
];

export const GOLD_VAULT = {
  goldBuy: 7238.4,
  goldSell: 7195.1,
  silverBuy: 91.25,
  silverSell: 90.4,
  purity: "99.9%",
  storage: "Insured vault storage, 0% making charges on digital gold",
};

<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class HoldingController extends Controller
{
    // GET /api/holdings.php -> [{ id, symbol, exchange, quantity, avg_price }]
    // Real portfolio data. The frontend fetches a live quote per symbol
    // (via getQuote in marketApi.js) and computes current value / P&L
    // client-side so it always reflects live prices, not a stale snapshot.
    public function index(Request $request)
    {
        $holdings = $request->user()->holdings()->orderBy('id')->get();

        return response()->json($holdings);
    }

    // POST /api/holdings/buy.php { symbol, exchange, quantity, price }
    // Debits the wallet, creates/increases the holding with a weighted
    // average buy price. Rejects if the wallet balance is insufficient.
    public function buy(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'symbol' => ['required', 'string', 'max:32'],
            'exchange' => ['nullable', 'string', 'max:16'],
            'quantity' => ['required', 'numeric', 'min:0.0001'],
            'price' => ['required', 'numeric', 'min:0.01'],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'message' => $validator->errors()->first(),
                'errors' => $validator->errors(),
            ], 422);
        }

        $symbol = strtoupper($request->symbol);
        $exchange = $request->exchange ?: 'NSE';
        $qty = (float) $request->quantity;
        $price = (float) $request->price;
        $cost = $qty * $price;

        return DB::transaction(function () use ($request, $symbol, $exchange, $qty, $price, $cost) {
            $user = $request->user()->lockForUpdate()->find($request->user()->id);

            if ((float) $user->balance < $cost) {
                return response()->json([
                    'message' => 'Insufficient wallet balance for this order.',
                ], 422);
            }

            $holding = $user->holdings()->where('symbol', $symbol)->first();

            if ($holding) {
                $newQty = (float) $holding->quantity + $qty;
                $newAvg = (((float) $holding->quantity * (float) $holding->avg_price) + $cost) / $newQty;
                $holding->quantity = $newQty;
                $holding->avg_price = $newAvg;
                $holding->exchange = $exchange;
                $holding->save();
            } else {
                $holding = $user->holdings()->create([
                    'symbol' => $symbol,
                    'exchange' => $exchange,
                    'quantity' => $qty,
                    'avg_price' => $price,
                ]);
            }

            $user->balance = (float) $user->balance - $cost;
            $user->save();

            return response()->json([
                'message' => 'Order executed.',
                'holding' => $holding->fresh(),
                'balance' => (float) $user->balance,
            ], 201);
        });
    }

    // POST /api/holdings/sell.php { symbol, quantity, price }
    // Credits the wallet at the given (live) sell price, reduces the
    // holding, and removes the row entirely once quantity hits zero.
    public function sell(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'symbol' => ['required', 'string', 'max:32'],
            'quantity' => ['required', 'numeric', 'min:0.0001'],
            'price' => ['required', 'numeric', 'min:0.01'],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'message' => $validator->errors()->first(),
                'errors' => $validator->errors(),
            ], 422);
        }

        $symbol = strtoupper($request->symbol);
        $qty = (float) $request->quantity;
        $price = (float) $request->price;
        $proceeds = $qty * $price;

        return DB::transaction(function () use ($request, $symbol, $qty, $proceeds) {
            $user = $request->user()->lockForUpdate()->find($request->user()->id);
            $holding = $user->holdings()->where('symbol', $symbol)->first();

            if (! $holding || (float) $holding->quantity < $qty) {
                return response()->json([
                    'message' => 'You do not hold enough quantity of this stock to sell.',
                ], 422);
            }

            $remaining = (float) $holding->quantity - $qty;

            if ($remaining <= 0.00001) {
                $holding->delete();
                $holding = null;
            } else {
                $holding->quantity = $remaining;
                $holding->save();
            }

            $user->balance = (float) $user->balance + $proceeds;
            $user->save();

            return response()->json([
                'message' => 'Order executed.',
                'holding' => $holding,
                'balance' => (float) $user->balance,
            ]);
        });
    }
}

<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return response()->json([
        'app' => 'Awake API',
        'status' => 'running',
        'docs' => 'See routes/api.php for endpoints. Frontend should call the /api base URL.',
    ]);
});

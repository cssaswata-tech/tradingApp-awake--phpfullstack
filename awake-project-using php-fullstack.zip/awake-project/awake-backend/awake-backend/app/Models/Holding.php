<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Holding extends Model
{
    protected $fillable = [
        'user_id',
        'symbol',
        'exchange',
        'quantity',
        'avg_price',
    ];

    protected function casts(): array
    {
        return [
            'quantity' => 'decimal:4',
            'avg_price' => 'decimal:2',
        ];
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}

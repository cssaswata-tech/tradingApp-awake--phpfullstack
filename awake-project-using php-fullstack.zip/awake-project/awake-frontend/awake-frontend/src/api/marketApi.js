// Live OHLC candle source for the Terminal and AI Analyzer.
//
// Primary source: Twelve Data (https://twelvedata.com) — free tier, no
// credit card, CORS-enabled, works directly from the browser. Get a free
// key and set VITE_TWELVEDATA_KEY in .env to switch this on.
//
// Fallback: if no key is set, or the request fails (offline, rate limit,
// unlisted symbol), a deterministic synthetic candle series is generated
// instead so the Terminal and Analyzer always have data to work with. The
// series is seeded from the symbol name, so the same symbol always produces
// the same "history" and indicator values stay stable between renders.

const TD_KEY = import.meta.env.VITE_TWELVEDATA_KEY || "";
const TD_BASE = "https://api.twelvedata.com";

// Indices already carry their own recognizable tickers; everything else in
// this app is an NSE-listed instrument, and Twelve Data expects the
// "SYMBOL:EXCHANGE" format for non-US markets (e.g. "TCS:NSE"). This lets
// the rest of the app keep using plain symbols like "TCS" everywhere.
const INDEX_SYMBOLS = new Set(["NIFTY50", "NIFTYNXT50", "NIFTYBANK", "INDIAVIX", "FINNIFTY"]);
function toTwelveDataSymbol(symbol) {
  if (symbol.includes(":") || symbol.includes("/")) return symbol;
  if (INDEX_SYMBOLS.has(symbol)) return symbol;
  return `${symbol}:NSE`;
}

function seedFromString(str) {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0;
  return h || 1;
}

function mulberry32(seed) {
  let a = seed;
  return function () {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// Generates ~180 daily candles ending "today" with a mild trend + noise,
// unique per symbol but stable across calls.
export function synthCandles(symbol, basePrice = 100, count = 180) {
  const rnd = mulberry32(seedFromString(symbol));
  const drift = (rnd() - 0.45) * 0.0016; // slight per-candle bias, seeded
  const vol = 0.012 + rnd() * 0.01;
  let price = basePrice * (0.7 + rnd() * 0.6);
  const candles = [];
  const now = Date.now();
  for (let i = count; i >= 0; i--) {
    const change = drift + (rnd() - 0.5) * vol;
    const open = price;
    price = Math.max(1, price * (1 + change));
    const high = Math.max(open, price) * (1 + rnd() * 0.006);
    const low = Math.min(open, price) * (1 - rnd() * 0.006);
    const volume = Math.floor(50000 + rnd() * 500000);
    candles.push({
      time: new Date(now - i * 86400000).toISOString().slice(0, 10),
      open: +open.toFixed(2),
      high: +high.toFixed(2),
      low: +low.toFixed(2),
      close: +price.toFixed(2),
      volume,
    });
  }
  return candles;
}

// Returns { candles, source: "live" | "simulated" }
export async function getCandles(symbol, { interval = "1day", outputsize = 200, basePriceHint = 100 } = {}) {
  if (TD_KEY) {
    try {
      const url = `${TD_BASE}/time_series?symbol=${encodeURIComponent(toTwelveDataSymbol(symbol))}&interval=${interval}&outputsize=${outputsize}&apikey=${TD_KEY}`;
      const res = await fetch(url);
      const json = await res.json();
      if (json && Array.isArray(json.values) && json.values.length > 5) {
        const candles = json.values
          .map((v) => ({
            time: v.datetime,
            open: +v.open,
            high: +v.high,
            low: +v.low,
            close: +v.close,
            volume: +(v.volume || 0),
          }))
          .reverse();
        return { candles, source: "live" };
      }
    } catch (e) {
      // fall through to simulated data
    }
  }
  return { candles: synthCandles(symbol, basePriceHint), source: "simulated" };
}

export async function getQuote(symbol, basePriceHint = 100) {
  if (TD_KEY) {
    try {
      const res = await fetch(`${TD_BASE}/quote?symbol=${encodeURIComponent(toTwelveDataSymbol(symbol))}&apikey=${TD_KEY}`);
      const json = await res.json();
      if (json && json.close) {
        return {
          symbol,
          price: +json.close,
          change: +json.change,
          changePct: +json.percent_change,
          source: "live",
        };
      }
    } catch (e) {
      // fall through
    }
  }
  const candles = synthCandles(symbol, basePriceHint, 2);
  const last = candles[candles.length - 1];
  const prev = candles[candles.length - 2];
  return {
    symbol,
    price: last.close,
    change: +(last.close - prev.close).toFixed(2),
    changePct: +(((last.close - prev.close) / prev.close) * 100).toFixed(2),
    source: "simulated",
  };
}

export const HAS_LIVE_KEY = !!TD_KEY;

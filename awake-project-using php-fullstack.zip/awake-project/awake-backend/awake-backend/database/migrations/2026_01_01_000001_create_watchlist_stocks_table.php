<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('watchlist_stocks', function (Blueprint $table) {
            $table->id();
            $table->foreignId('watchlist_id')->constrained()->cascadeOnDelete();
            $table->string('symbol');
            $table->string('exchange')->default('NSE');
            $table->timestamps();

            $table->unique(['watchlist_id', 'symbol']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('watchlist_stocks');
    }
};

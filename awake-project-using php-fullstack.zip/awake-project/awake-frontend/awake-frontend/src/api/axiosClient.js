import axios from "axios";

// Base URL points at the PHP backend (built in the next part).
const BASE_URL = import.meta.env.VITE_API_URL || "http://localhost/awake-backend/api";

const axiosClient = axios.create({ baseURL: BASE_URL, timeout: 15000 });

// Attach JWT on every request
axiosClient.interceptors.request.use((config) => {
  const token = localStorage.getItem("awake_token");
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Auto logout on 401 from backend
axiosClient.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response && err.response.status === 401) {
      localStorage.removeItem("awake_token");
      localStorage.removeItem("awake_user");
      window.location.href = "/login";
    }
    return Promise.reject(err);
  }
);

// ---- Endpoint map used across the app (implement these in PHP) ----
// POST   /auth/register.php        { name, email, password }
// POST   /auth/login.php           { email, password } -> { token, user }
// GET    /watchlists.php           -> [{ id, name, stocks:[...] }]
// POST   /watchlists.php           { name } -> created watchlist
// DELETE /watchlists.php?id=       remove a watchlist
// POST   /watchlist_stocks.php     { watchlist_id, symbol, exchange } -> add stock
// DELETE /watchlist_stocks.php?id= remove stock from watchlist
// GET    /holdings.php             -> [{ id, symbol, exchange, quantity, avg_price }]
// POST   /holdings/buy.php         { symbol, exchange, quantity, price } -> debits wallet
// POST   /holdings/sell.php        { symbol, quantity, price } -> credits wallet
// GET    /market/quote.php?symbol= live quote for terminal page
// GET    /market/movers.php        gainers/losers/volume
// GET    /ipo/list.php             latest IPOs
// POST   /money/add.php            { amount } -> add funds, returns { balance }
// GET    /money/balance.php        -> { balance }
// GET    /stocks/nifty500.php?q=   -> [{ symbol, name, exchange }] Nifty 500 universe

export default axiosClient;

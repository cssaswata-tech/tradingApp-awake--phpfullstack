import { useParams, useNavigate } from "react-router-dom";
import { useEffect, useMemo, useState } from "react";
import useLiveData from "../hooks/useLiveData";
import { SEED_STOCKS, MOVERS } from "../api/mockData";
import { NIFTY500_UNIQUE } from "../api/nifty500";
import { getCandles } from "../api/marketApi";
import { buildIndicatorRegistry } from "../lib/indicators";
import { heikinAshi, renko } from "../lib/chartTransforms";
import BuySellModal from "../components/BuySellModal";
import { useAuth } from "../context/AuthContext";

const DEFAULT_ON = ["sma20", "sma50", "rsi14", "macd_line"];
const DEFAULT_LAYOUT = { enabled: DEFAULT_ON, chartType: "candle" };
const LAYOUT_KEY = "awake_terminal_layout";
const LAST_SYMBOL_KEY = "awake_last_terminal_symbol";
const OVERLAY_COLORS = ["#facc15", "#38bdf8", "#c084fc", "#fb923c", "#f472b6", "#a3e635"];
const DISPLAY_COUNT = 80;
const CHART_TYPES = [
  { id: "candle", label: "Candles" },
  { id: "heikin", label: "Heikin-Ashi" },
  { id: "line", label: "Line" },
  { id: "volume", label: "Volume" },
  { id: "renko", label: "Renko" },
];

function loadLayout() {
  try {
    const raw = localStorage.getItem(LAYOUT_KEY);
    if (!raw) return DEFAULT_LAYOUT;
    const parsed = JSON.parse(raw);
    return { enabled: parsed.enabled || DEFAULT_ON, chartType: parsed.chartType || "candle" };
  } catch {
    return DEFAULT_LAYOUT;
  }
}

function scaleY(v, min, max, h) {
  const range = max - min || 1;
  return h - ((v - min) / range) * h;
}

export default function Terminal() {
  const { symbol: routeSymbol } = useParams();
  const nav = useNavigate();
  const { user } = useAuth();
  const [orderSide, setOrderSide] = useState(null); // "buy" | "sell" | null

  const initialLayout = useMemo(loadLayout, []);
  const [symbolInput, setSymbolInput] = useState(routeSymbol || localStorage.getItem(LAST_SYMBOL_KEY) || "TCS");
  const symbol = routeSymbol || localStorage.getItem(LAST_SYMBOL_KEY) || "TCS";

  const [enabled, setEnabled] = useState(() => new Set(initialLayout.enabled));
  const [chartType, setChartType] = useState(initialLayout.chartType);
  const [query, setQuery] = useState("");
  const [savedFlash, setSavedFlash] = useState(false);

  useEffect(() => {
    if (!routeSymbol) nav(`/terminal/${symbol}`, { replace: true });
    localStorage.setItem(LAST_SYMBOL_KEY, symbol);
    // eslint-disable-next-line
  }, [symbol]);

  const seed = useMemo(() => {
    const all = [...SEED_STOCKS, ...MOVERS.gainers, ...MOVERS.losers, ...MOVERS.volume];
    const found = all.find((s) => s.symbol === symbol);
    if (found) return found;
    const n500 = NIFTY500_UNIQUE.find((s) => s.symbol === symbol);
    return { symbol, name: n500?.name || symbol, exchange: n500?.exchange || "NSE", price: 100, change: 0, changePct: 0 };
  }, [symbol]);

  const [live] = useLiveData([seed], 1200);
  const [candles, setCandles] = useState(null);
  const [source, setSource] = useState(null);

  useEffect(() => {
    let cancelled = false;
    setCandles(null);
    getCandles(symbol, { basePriceHint: seed.price }).then(({ candles, source }) => {
      if (!cancelled) { setCandles(candles); setSource(source); }
    });
    return () => { cancelled = true; };
    // eslint-disable-next-line
  }, [symbol]);

  const registry = useMemo(() => (candles ? buildIndicatorRegistry(candles) : []), [candles]);

  const groups = useMemo(() => {
    const m = {};
    registry.forEach((i) => { (m[i.group] ||= []).push(i); });
    return m;
  }, [registry]);

  function toggle(id) {
    setEnabled((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  }

  function saveLayout() {
    localStorage.setItem(LAYOUT_KEY, JSON.stringify({ enabled: Array.from(enabled), chartType }));
    setSavedFlash(true);
    setTimeout(() => setSavedFlash(false), 1800);
  }

  function resetLayout() {
    localStorage.removeItem(LAYOUT_KEY);
    setEnabled(new Set(DEFAULT_ON));
    setChartType("candle");
  }

  function goToSymbol(e) {
    e.preventDefault();
    const sym = symbolInput.trim().toUpperCase();
    if (sym) nav(`/terminal/${sym}`);
  }

  const depth = useMemo(() => {
    const base = live.price;
    return Array.from({ length: 5 }).map((_, i) => ({
      bidPrice: (base - (i + 1) * 0.15).toFixed(2),
      bidQty: Math.floor(Math.random() * 500 + 20),
      askPrice: (base + (i + 1) * 0.15).toFixed(2),
      askQty: Math.floor(Math.random() * 500 + 20),
    }));
  }, [live.price]);

  const chartW = 700, chartH = 300;

  // Candles sliced for display so individual candles/bricks stay readable;
  // full `candles` array is still used for indicator math above.
  const displayCandles = useMemo(() => (candles ? candles.slice(-DISPLAY_COUNT) : []), [candles]);
  const sliceStart = candles ? candles.length - displayCandles.length : 0;

  const haCandles = useMemo(() => (chartType === "heikin" && candles ? heikinAshi(candles).slice(-DISPLAY_COUNT) : null), [chartType, candles]);
  const renkoData = useMemo(() => (chartType === "renko" && candles ? renko(candles) : null), [chartType, candles]);

  const priceCandles = chartType === "heikin" ? haCandles : displayCandles;

  const enabledOverlays = useMemo(
    () => (chartType === "volume" || chartType === "renko" ? [] : registry.filter((i) => i.overlay && enabled.has(i.id))),
    [registry, enabled, chartType]
  );

  const chartData = useMemo(() => {
    if (!candles || !priceCandles || !priceCandles.length) return null;

    if (chartType === "renko" && renkoData) {
      const { bricks, brickSize } = renkoData;
      if (!bricks.length) return { empty: true };
      const prices = bricks.flatMap((b) => [b.open, b.close]);
      const min = Math.min(...prices), max = Math.max(...prices);
      const bw = chartW / Math.min(bricks.length, 60);
      const shown = bricks.slice(-60);
      const boxes = shown.map((b, i) => {
        const top = scaleY(Math.max(b.open, b.close), min, max, chartH);
        const bottom = scaleY(Math.min(b.open, b.close), min, max, chartH);
        return { x: i * bw, y: top, w: bw * 0.82, h: Math.max(2, bottom - top), up: b.dir > 0 };
      });
      return { type: "renko", boxes, brickSize };
    }

    if (chartType === "volume") {
      const vols = displayCandles.map((c) => c.volume || 0);
      const maxV = Math.max(...vols, 1);
      const bw = chartW / displayCandles.length;
      const bars = displayCandles.map((c, i) => ({
        x: i * bw,
        w: bw * 0.7,
        h: (c.volume / maxV) * chartH,
        up: c.close >= c.open,
      }));
      return { type: "volume", bars };
    }

    const closesForScale = priceCandles.map((c) => c.close);
    const highsLows = priceCandles.flatMap((c) => [c.high, c.low]);
    const overlaySlices = enabledOverlays.map((ind) => ind.series.slice(sliceStart));
    const overlayVals = overlaySlices.flat().filter((v) => v != null);
    const allVals = [...highsLows, ...overlayVals];
    const min = Math.min(...allVals), max = Math.max(...allVals);

    if (chartType === "line") {
      const y = closesForScale.map((c) => scaleY(c, min, max, chartH));
      const pricePoints = y.map((v, i) => `${(i / (y.length - 1)) * chartW},${v}`).join(" ");
      const overlays = enabledOverlays.map((ind, idx) => {
        const series = overlaySlices[idx];
        const pts = series.map((v, i) => (v == null ? null : `${(i / (series.length - 1)) * chartW},${scaleY(v, min, max, chartH)}`)).filter(Boolean).join(" ");
        return { id: ind.id, label: ind.label, color: OVERLAY_COLORS[idx % OVERLAY_COLORS.length], pts };
      });
      return { type: "line", pricePoints, overlays };
    }

    // candle / heikin-ashi
    const bw = chartW / priceCandles.length;
    const candleShapes = priceCandles.map((c, i) => ({
      x: i * bw + bw / 2,
      bodyX: i * bw + bw * 0.15,
      bodyW: bw * 0.7,
      wickTop: scaleY(c.high, min, max, chartH),
      wickBottom: scaleY(c.low, min, max, chartH),
      bodyTop: scaleY(Math.max(c.open, c.close), min, max, chartH),
      bodyBottom: scaleY(Math.min(c.open, c.close), min, max, chartH),
      up: c.close >= c.open,
    }));
    const overlays = enabledOverlays.map((ind, idx) => {
      const series = overlaySlices[idx];
      const pts = series.map((v, i) => (v == null ? null : `${(i / (series.length - 1)) * chartW},${scaleY(v, min, max, chartH)}`)).filter(Boolean).join(" ");
      return { id: ind.id, label: ind.label, color: OVERLAY_COLORS[idx % OVERLAY_COLORS.length], pts };
    });
    return { type: "candle", candleShapes, overlays };
  }, [candles, priceCandles, chartType, renkoData, displayCandles, enabledOverlays, sliceStart]);

  const oscillatorPanels = registry.filter((i) => !i.overlay && enabled.has(i.id));

  const filteredGroups = Object.entries(groups).map(([g, items]) => [
    g, items.filter((i) => i.label.toLowerCase().includes(query.toLowerCase())),
  ]).filter(([, items]) => items.length);

  return (
    <div className="terminal-page">
      <div className="card" style={{ marginBottom: 16 }}>
        <form className="search" onSubmit={goToSymbol} style={{ marginBottom: 0 }}>
          🔍 <input value={symbolInput} onChange={(e) => setSymbolInput(e.target.value)} placeholder="Jump to any symbol e.g. TCS, RELIANCE, INFY" />
          <button className="btn" type="submit">Go</button>
        </form>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 10 }}>
          {NIFTY500_UNIQUE.slice(0, 12).map((s) => (
            <button key={s.symbol} className="chip" onClick={() => nav(`/terminal/${s.symbol}`)}>{s.symbol}</button>
          ))}
        </div>
      </div>

      <div className="terminal-header">
        <div>
          <h2 style={{ margin: 0 }}>{live.name} <small style={{ color: "var(--muted)" }}>{live.exchange}</small></h2>
          <div className={live.change >= 0 ? "up" : "down"}>
            {live.change >= 0 ? "+" : ""}{live.change.toFixed(2)} ({live.changePct.toFixed(2)}%)
            {source && <span style={{ color: "var(--muted)", marginLeft: 10, fontSize: 12 }}>{source === "live" ? "● live" : "● simulated"}</span>}
          </div>
        </div>
        <div className="px">₹{live.price.toFixed(2)}</div>
        <div>
          <button className="btn secondary" style={{ marginRight: 8 }} onClick={() => nav(`/analyzer/${symbol}`)}>🤖 Analyze with AI</button>
          <button
            className="btn"
            style={{ marginRight: 8 }}
            onClick={() => (user ? setOrderSide("buy") : nav("/login"))}
          >
            Buy
          </button>
          <button className="btn danger" onClick={() => (user ? setOrderSide("sell") : nav("/login"))}>
            Sell
          </button>
        </div>
      </div>

      <div className="terminal-grid-3">
        <div className="card">
          <div className="row-between">
            <h3>Chart</h3>
            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
              {savedFlash && <span className="up" style={{ fontSize: 12 }}>✓ Layout saved</span>}
              <button className="btn secondary" onClick={saveLayout}>💾 Save Layout</button>
              <button className="btn secondary" onClick={resetLayout}>↺ Reset</button>
            </div>
          </div>

          <div className="tabs-row">
            {CHART_TYPES.map((t) => (
              <button key={t.id} className={t.id === chartType ? "active" : ""} onClick={() => setChartType(t.id)}>{t.label}</button>
            ))}
          </div>

          {!chartData ? <div className="chart-fake" /> : (
            <>
              <svg width="100%" viewBox={`0 0 ${chartW} ${chartH}`} preserveAspectRatio="none" className="chart-svg">
                {chartData.type === "line" && (
                  <>
                    <polyline fill="none" stroke={live.change >= 0 ? "#22c55e" : "#f04a4a"} strokeWidth="2" points={chartData.pricePoints} />
                    {chartData.overlays.map((o) => (
                      <polyline key={o.id} fill="none" stroke={o.color} strokeWidth="1.5" opacity="0.85" points={o.pts} />
                    ))}
                  </>
                )}
                {chartData.type === "candle" && (
                  <>
                    {chartData.candleShapes.map((c, i) => (
                      <g key={i}>
                        <line x1={c.x} x2={c.x} y1={c.wickTop} y2={c.wickBottom} stroke={c.up ? "#22c55e" : "#f04a4a"} strokeWidth="1" />
                        <rect x={c.bodyX} y={c.bodyTop} width={c.bodyW} height={Math.max(1, c.bodyBottom - c.bodyTop)} fill={c.up ? "#22c55e" : "#f04a4a"} />
                      </g>
                    ))}
                    {chartData.overlays.map((o) => (
                      <polyline key={o.id} fill="none" stroke={o.color} strokeWidth="1.5" opacity="0.9" points={o.pts} />
                    ))}
                  </>
                )}
                {chartData.type === "volume" && chartData.bars.map((b, i) => (
                  <rect key={i} x={b.x} y={chartH - b.h} width={b.w} height={b.h} fill={b.up ? "#22c55e" : "#f04a4a"} opacity="0.85" />
                ))}
                {chartData.type === "renko" && !chartData.empty && chartData.boxes.map((b, i) => (
                  <rect key={i} x={b.x} y={b.y} width={b.w} height={b.h} fill={b.up ? "#22c55e" : "#f04a4a"} stroke="var(--bg)" strokeWidth="1" />
                ))}
                {chartData.empty && <text x="10" y="20" fill="var(--muted)" fontSize="12">Not enough movement yet to form a Renko brick.</text>}
              </svg>
              {chartData.overlays && chartData.overlays.length > 0 && (
                <div className="legend">
                  {chartData.overlays.map((o) => (
                    <span key={o.id}><i style={{ background: o.color }} />{o.label}</span>
                  ))}
                </div>
              )}
              {chartType === "renko" && chartData.brickSize && (
                <div style={{ color: "var(--muted)", fontSize: 12, marginTop: 4 }}>Brick size ≈ ₹{chartData.brickSize.toFixed(2)}</div>
              )}
            </>
          )}

          {oscillatorPanels.length > 0 && (
            <div className="osc-panels">
              {oscillatorPanels.map((ind) => (
                <div key={ind.id} className="osc-row">
                  <div className="osc-label">{ind.label}</div>
                  <div className="osc-value">{ind.latest != null ? ind.latest.toFixed(2) : "—"}</div>
                </div>
              ))}
            </div>
          )}

          <h3 style={{ marginTop: 18 }}>Market Depth</h3>
          <div className="orderbook-row"><b>Bid Qty</b><b>Bid</b><b>Ask</b><b>Ask Qty</b></div>
          {depth.map((d, i) => (
            <div className="orderbook-row" key={i}>
              <span>{d.bidQty}</span>
              <span className="up">{d.bidPrice}</span>
              <span className="down">{d.askPrice}</span>
              <span>{d.askQty}</span>
            </div>
          ))}
        </div>

        <div className="card indicator-picker">
          <h3>Indicators <small style={{ color: "var(--muted)", fontWeight: 400 }}>({enabled.size} active)</small></h3>
          <div className="search" style={{ marginBottom: 10 }}>
            🔍 <input placeholder="Search 30 indicators…" value={query} onChange={(e) => setQuery(e.target.value)} />
          </div>
          {!candles ? <div style={{ color: "var(--muted)" }}>Loading indicator data…</div> : (
            filteredGroups.map(([group, items]) => (
              <div key={group} className="indicator-group">
                <div className="indicator-group-title">{group}</div>
                {items.map((ind) => (
                  <label key={ind.id} className="indicator-check">
                    <input type="checkbox" checked={enabled.has(ind.id)} onChange={() => toggle(ind.id)} />
                    <span>{ind.label}</span>
                    <span className="indicator-latest">{ind.latest != null ? ind.latest.toFixed(2) : "—"}</span>
                  </label>
                ))}
              </div>
            ))
          )}
        </div>
      </div>

      {orderSide && (
        <BuySellModal
          side={orderSide}
          symbol={symbol}
          exchange={live.exchange}
          price={live.price}
          onClose={() => setOrderSide(null)}
        />
      )}
    </div>
  );
}

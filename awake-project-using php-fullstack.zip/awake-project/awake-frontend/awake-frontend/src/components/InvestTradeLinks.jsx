import { useNavigate } from "react-router-dom";

const TILES = [
  { icon: "🥧", label: "Equities", to: "/markets?tab=equities" },
  { icon: "🌱", label: "Mutual Funds", to: "/markets?tab=mf" },
  { icon: "📈", label: "ETFs", to: "/markets?tab=etf" },
  { icon: "🔷", label: "Options", to: "/markets?tab=options" },
  { icon: "🏦", label: "Futures", to: "/markets?tab=futures" },
  { icon: "🔺", label: "Commodities", to: "/markets?tab=commodities" },
];

export default function InvestTradeLinks({ onOpenMoney }) {
  const nav = useNavigate();
  return (
    <div className="card">
      <h3>Invest / Trade on Stock Exchanges</h3>
      <div className="grid-3">
        {TILES.map((t) => (
          <div key={t.label} className="link-tile" onClick={() => nav(t.to)}>
            <span>{t.icon}</span> {t.label}
          </div>
        ))}
      </div>
      <div className="banner-link" onClick={() => nav("/markets?tab=rent-stocks")}>
        <span>📦 Rent Stocks — Earn upto 18% pa with SLBM</span> <span>→</span>
      </div>
      <div className="banner-link" onClick={() => nav("/markets?tab=gold-vault")}>
        <span>🪙 Gold Vault — Buy 99.9% pure Gold and Silver</span> <span>→</span>
      </div>
      <div className="banner-link" onClick={onOpenMoney}>
        <span>💰 Money — Add funds to your account</span> <span>→</span>
      </div>
    </div>
  );
}

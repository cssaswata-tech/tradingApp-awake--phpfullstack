import { useState } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Navbar({ onOpenMoney }) {
  const { user, balance, logout } = useAuth();
  const [profileOpen, setProfileOpen] = useState(false);
  const nav = useNavigate();

  return (
    <div className="navbar">
      <div className="brand">🟢 awake</div>
      <div className="links">
        <NavLink to="/" end className={({isActive}) => isActive ? "active" : ""}>Home</NavLink>
        <NavLink to="/markets" className={({isActive}) => isActive ? "active" : ""}>Markets</NavLink>
        <NavLink to="/terminal" className={({isActive}) => isActive ? "active" : ""}>Terminal</NavLink>
        <NavLink to="/ipo" className={({isActive}) => isActive ? "active" : ""}>IPOs</NavLink>
        <NavLink to="/analyzer" className={({isActive}) => isActive ? "active" : ""}>🤖 AI Analyzer</NavLink>
        {user && <a onClick={onOpenMoney} style={{cursor:"pointer"}}>Money</a>}
      </div>
      <div className="right">
        {user ? (
          <>
            <div className="profile-wrap">
              <button className="profile-trigger" onClick={() => setProfileOpen((v) => !v)}>
                <span className="avatar">{user.name?.[0]?.toUpperCase() || "U"}</span>
                <span>{user.name}</span>
              </button>
              {profileOpen && (
                <div className="profile-dropdown" onMouseLeave={() => setProfileOpen(false)}>
                  <div className="profile-header">
                    <span className="avatar big">{user.name?.[0]?.toUpperCase() || "U"}</span>
                    <div>
                      <div className="profile-name">{user.name}</div>
                      <div className="profile-email">{user.email}</div>
                    </div>
                  </div>
                  <div className="profile-balance">
                    <label>Wallet Balance</label>
                    <div className="val">
                      ₹{Number(balance || 0).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </div>
                  </div>
                  <button className="btn" style={{ width: "100%", marginTop: 10 }} onClick={() => { setProfileOpen(false); onOpenMoney(); }}>
                    + Add Money
                  </button>
                </div>
              )}
            </div>
            <button className="btn secondary" onClick={() => { logout(); nav("/login"); }}>Logout</button>
          </>
        ) : (
          <>
            <button className="btn secondary" onClick={() => nav("/login")}>Login</button>
            <button className="btn" onClick={() => nav("/register")}>Register</button>
          </>
        )}
      </div>
    </div>
  );
}

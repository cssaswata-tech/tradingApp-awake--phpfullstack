# Awake — React Frontend

Frontend-only build (no PHP yet, as requested). Fully working with simulated
live data and localStorage-based watchlist CRUD, already wired for a PHP + JWT
backend — every place that will call the backend has a comment showing the
exact axios call to use.

## Run it

```
npm install
npm run dev
```

Open http://localhost:5173

## What's included

- **Home** — live index ticker, portfolio summary, watchlist, clickable
  Equities / Mutual Funds / ETFs / Options / Futures / Commodities / Rent
  Stocks / Gold Vault tiles, Market Movers (Gainers/Losers/Top Volume),
  Trending Stocks.
- **Watchlist CRUD** — create a new named watchlist, add a stock (Create),
  view list live (Read), click a stock name to open it in the Terminal
  (Read → redirect), remove a stock or delete a whole list (Delete).
- **Terminal** — now a standalone section (`/terminal` in the navbar, or
  `/terminal/:symbol`). Has its own symbol search so you're not limited to
  clicking a stock elsewhere first. Four chart types: **Candlestick**,
  **Heikin-Ashi**, **Line**, **Volume**, and **Renko** (brick chart built
  from price movement, ignoring time — see `src/lib/chartTransforms.js`),
  plus the 30-indicator picker with overlays on the price chart and
  oscillators in a values panel. **💾 Save Layout** persists your chosen
  indicators + chart type to `localStorage` so they're there next time you
  open the Terminal on any symbol; **↺ Reset** clears it back to defaults.
- **AI Stock Analyzer** (`/analyzer/:symbol`) — enter any symbol and get a
  BUY / HOLD / SELL call. This is rule-based technical analysis (not an LLM
  call) — it scores ~15 well-known signals (trend vs moving averages, RSI,
  MACD crossover, Bollinger position, Stochastic, Williams %R, CCI, ADX
  trend strength) and shows the reasoning for every signal, not just a
  black-box answer. Logic lives in `src/lib/analyzer.js`.
- **Live data source** (`src/api/marketApi.js`) — pulls real OHLC candles
  from [Twelve Data](https://twelvedata.com/pricing) (free tier, no card,
  CORS-enabled) when `VITE_TWELVEDATA_KEY` is set in `.env`. Without a key,
  or if a request fails, it automatically falls back to a deterministic
  simulated candle series seeded from the symbol name, so the Terminal and
  Analyzer always work out of the box.
- **IPO page** (`/ipo`) — latest IPOs with status badges (open/upcoming/listed).
- **Markets page** (`/markets?tab=...`) — every tile now renders real,
  distinct data for its section instead of reusing the equities list:
  Equities and ETFs (live-ticking price lists), Mutual Funds (NAV / 1Y
  return / risk table), Futures (contract / expiry / OI table), Options
  (a live-built option chain per underlying), Commodities (MCX-style price
  list), Rent Stocks (SLBM lending rates), and Gold Vault (buy/sell spot
  prices). Free, no-signup live feeds aren't realistically available for
  Indian options chains, futures OI, or MF NAVs, so those sections use
  representative data — swap in a paid vendor later behind the same
  components if needed.
- **Money modal** — opens from the Money nav link, the "+Top Up" style
  banner, and the sidebar; currently simulates adding funds locally.
- **Auth pages** (`/login`, `/register`) — call `POST /auth/login.php` and
  `POST /auth/register.php` via axios and store the returned JWT.

## Getting free live price data (Terminal + AI Analyzer)

The app ships fully working on **simulated** data — no signup needed. To
switch on **real** live/historical prices:

1. Sign up free at [twelvedata.com](https://twelvedata.com) — no credit
   card required. Copy your API key from the dashboard.
2. Add it to `.env`:
   ```
   VITE_TWELVEDATA_KEY=your_key_here
   ```
3. Restart `npm run dev`.

Symbols are auto-formatted internally as `SYMBOL:NSE` (e.g. `TCS` becomes
`TCS:NSE`), so you keep using plain symbols everywhere in the UI. Free tier
gives ~800 requests/day; if a specific NSE symbol isn't available on the
free plan, or you're offline, the app quietly falls back to simulated data
for that symbol instead of breaking — you'll see a "● live" or
"● simulated" tag on the Terminal so you always know which you're looking
at.

A couple of things worth knowing if you outgrow this:
- Twelve Data's free plan is EOD/delayed for most non-US symbols, not
  tick-by-tick real-time — fine for charts and indicators, not for a real
  brokerage.
- An OpenAI/LLM API key is **not** a market-data source — it can't fetch
  prices. It could add a plain-English narrative layer on top of the
  Analyzer's existing signals, but that call has to run on a backend that
  holds the key server-side; never put an LLM key in frontend code, since
  anything shipped to the browser is visible to every visitor.

## AI Explanation backend (optional — /server)

The Analyzer's technical-analysis verdict (BUY/HOLD/SELL) works with zero
setup — it's pure math in `src/lib/analyzer.js`. The **"🤖 Get AI
Explanation"** button on the results page is optional on top of that: it
turns the already-computed signals into a plain-English paragraph using
OpenAI, through a tiny backend in `/server` that's the only place your key
should ever live.

```
cd server
cp .env.example .env      # then paste your OpenAI key into OPENAI_API_KEY=
npm install
npm start                 # runs on http://localhost:5000
```

Then in the frontend's own `.env`, make sure `VITE_BACKEND_URL` points at
it (defaults to `http://localhost:5000`, matching the backend above).

Why it's split this way: this is a Vite/React app, so anything under
`VITE_*` in the frontend `.env` gets bundled straight into the JavaScript
every visitor's browser downloads — view-source or the Network tab reveals
it instantly. A secret key can only be safe on a server that the browser
merely *talks to*, never one whose code the browser *runs*. `server/index.js`
is that server: it receives the already-computed verdict and signals from
the frontend, asks OpenAI to phrase them nicely, and returns text — the key
itself never leaves the backend process.

## Connecting the PHP backend (next step)

1. Set `VITE_API_URL` in a `.env` file (see `.env.example`) to your PHP API
   base URL.
2. In `src/context/WatchlistContext.jsx`, replace the localStorage logic in
   each CRUD function with the axios call shown in the comment above it.
3. In `src/pages/Terminal.jsx` and `src/components/MarketMovers.jsx`, replace
   `useLiveData`'s mock tick with a `setInterval`/WebSocket call to
   `/market/quote.php` or `/market/movers.php`.
4. `src/api/axiosClient.js` already attaches the JWT to every request and
   auto-logs-out on a 401, so nothing else needs to change once the backend
   is live.

Ask for the PHP backend next and I'll build the matching MySQL schema + JWT
auth + full CRUD endpoints for watchlists, quotes, IPOs, and money.

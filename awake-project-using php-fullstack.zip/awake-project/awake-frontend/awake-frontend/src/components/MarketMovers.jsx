import { useState } from "react";
import { useNavigate } from "react-router-dom";
import useLiveData from "../hooks/useLiveData";
import { MOVERS } from "../api/mockData";

export default function MarketMovers() {
  const [tab, setTab] = useState("gainers");
  const nav = useNavigate();
  const list = useLiveData(MOVERS[tab], 3000);

  return (
    <div className="card">
      <div className="row-between">
        <h3>Market Movers</h3>
      </div>
      <div className="tabs-row">
        <button className={tab === "gainers" ? "active" : ""} onClick={() => setTab("gainers")}>📈 Gainers</button>
        <button className={tab === "losers" ? "active" : ""} onClick={() => setTab("losers")}>📉 Losers</button>
        <button className={tab === "volume" ? "active" : ""} onClick={() => setTab("volume")}>Top Volume</button>
      </div>
      {list.map((s) => (
        <div className="mover-row" key={s.symbol} style={{ cursor: "pointer" }} onClick={() => nav(`/terminal/${s.symbol}`)}>
          <div className="mover-left">
            <div className="avatar">{s.symbol[0]}</div>
            <div>{s.name}</div>
          </div>
          <div className="price">
            <div>{s.price.toFixed(2)}</div>
            <small className={s.change >= 0 ? "up" : "down"}>
              {s.change >= 0 ? "+" : ""}{s.change.toFixed(2)} ({s.changePct.toFixed(2)}%)
            </small>
          </div>
        </div>
      ))}
    </div>
  );
}

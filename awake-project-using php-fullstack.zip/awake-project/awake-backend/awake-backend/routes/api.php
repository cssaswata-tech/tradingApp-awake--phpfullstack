<?php

use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\HoldingController;
use App\Http\Controllers\Api\IpoController;
use App\Http\Controllers\Api\MarketController;
use App\Http\Controllers\Api\MoneyController;
use App\Http\Controllers\Api\StockController;
use App\Http\Controllers\Api\WatchlistController;
use App\Http\Controllers\Api\WatchlistStockController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| These paths intentionally match src/api/axiosClient.js in the React app
| 1-for-1 (including the ".php" endings), so the frontend can point
| VITE_API_URL at this backend with no code changes on the React side.
|
*/

// ---- Auth (public) ----
Route::post('/auth/register.php', [AuthController::class, 'register']);
Route::post('/auth/login.php', [AuthController::class, 'login']);

// ---- Everything below requires a valid Sanctum bearer token ----
Route::middleware('auth:sanctum')->group(function () {
    Route::post('/auth/logout.php', [AuthController::class, 'logout']);
    Route::get('/auth/me.php', [AuthController::class, 'me']);

    // Watchlists (list/create/delete)
    Route::get('/watchlists.php', [WatchlistController::class, 'index']);
    Route::post('/watchlists.php', [WatchlistController::class, 'store']);
    Route::delete('/watchlists.php', [WatchlistController::class, 'destroy']); // ?id=

    // Stocks inside a watchlist (add/remove)
    Route::post('/watchlist_stocks.php', [WatchlistStockController::class, 'store']);
    Route::delete('/watchlist_stocks.php', [WatchlistStockController::class, 'destroy']); // ?id=

    // Money / funds
    Route::post('/money/add.php', [MoneyController::class, 'add']);
    Route::get('/money/balance.php', [MoneyController::class, 'balance']);

    // Holdings (real portfolio: buy/sell debits/credits wallet balance)
    Route::get('/holdings.php', [HoldingController::class, 'index']);
    Route::post('/holdings/buy.php', [HoldingController::class, 'buy']);
    Route::post('/holdings/sell.php', [HoldingController::class, 'sell']);
});

// ---- Market data (public stubs — wire these up to a real data provider) ----
Route::get('/market/quote.php', [MarketController::class, 'quote']);
Route::get('/market/movers.php', [MarketController::class, 'movers']);
Route::get('/ipo/list.php', [IpoController::class, 'index']);

// ---- Stock universe (public) ----
Route::get('/stocks/nifty500.php', [StockController::class, 'index']); // ?q=search term


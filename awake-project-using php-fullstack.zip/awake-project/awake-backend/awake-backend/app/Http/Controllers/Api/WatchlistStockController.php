<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\WatchlistStock;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class WatchlistStockController extends Controller
{
    // POST /api/watchlist_stocks.php { watchlist_id, symbol, exchange } -> add stock
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'watchlist_id' => ['required', 'integer'],
            'symbol' => ['required', 'string', 'max:32'],
            'exchange' => ['nullable', 'string', 'max:16'],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'message' => $validator->errors()->first(),
                'errors' => $validator->errors(),
            ], 422);
        }

        // Make sure the watchlist actually belongs to the authenticated user.
        $watchlist = $request->user()->watchlists()->where('id', $request->watchlist_id)->first();

        if (! $watchlist) {
            return response()->json(['message' => 'Watchlist not found.'], 404);
        }

        $stock = $watchlist->stocks()->create([
            'symbol' => strtoupper($request->symbol),
            'exchange' => $request->exchange ?? 'NSE',
        ]);

        return response()->json($stock, 201);
    }

    // DELETE /api/watchlist_stocks.php?id=
    public function destroy(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'id' => ['required', 'integer'],
        ]);

        if ($validator->fails()) {
            return response()->json(['message' => 'id is required.'], 422);
        }

        $stock = WatchlistStock::whereHas('watchlist', function ($q) use ($request) {
            $q->where('user_id', $request->user()->id);
        })->where('id', $request->query('id'))->first();

        if (! $stock) {
            return response()->json(['message' => 'Stock not found.'], 404);
        }

        $stock->delete();

        return response()->json(['message' => 'Stock removed.']);
    }
}

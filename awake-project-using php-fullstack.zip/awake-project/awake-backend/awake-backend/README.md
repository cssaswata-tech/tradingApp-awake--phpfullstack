# Awake — Laravel API Backend

Laravel 12 API backend built to plug directly into the `awake` React frontend.
Routes are named to match `src/api/axiosClient.js` in the frontend **exactly**
(including the `.php`-style endings), so once this is running you only need to
set one env var on the React side — no frontend code changes required.

## What's included

- **Auth**: register / login / logout using Laravel Sanctum (Bearer token, not cookies)
- **Watchlists**: full CRUD (create/list watchlist, add/remove a stock in it) scoped to the logged-in user
- **Stubs** for `market/quote`, `market/movers`, `ipo/list`, `money/add` — wired up and ready, just add your real data source

## Requirements

- PHP >= 8.2 with the usual extensions (pdo_mysql, mbstring, openssl, tokenizer, xml, ctype, json, bcmath)
- Composer 2
- MySQL (this is what `.env.example` is set up for — e.g. via XAMPP/phpMyAdmin) — SQLite also works, see below

## 1. Install dependencies

```bash
composer install
```

## 2. Configure environment

```bash
cp .env.example .env
php artisan key:generate
```

By default `.env` targets MySQL:

```
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=awake
DB_USERNAME=root
DB_PASSWORD=
```

Create the database first (e.g. in phpMyAdmin or the mysql CLI):

```sql
CREATE DATABASE awake;
```

**Prefer SQLite instead?** Comment out the MySQL block in `.env` and use:

```
DB_CONNECTION=sqlite
```

then:

```bash
touch database/database.sqlite
```

## 3. Run migrations

```bash
php artisan migrate
```

This creates `users`, `personal_access_tokens` (Sanctum), `watchlists`, and `watchlist_stocks`.

## 4. Serve it

```bash
php artisan serve
```

API is now at `http://localhost:8000/api`.

## 5. Point the React frontend at it

In the `awake` frontend, create/edit `.env`:

```
VITE_API_URL=http://localhost:8000/api
```

That's it — `axiosClient.js` already points here, and `AuthContext.jsx` /
`WatchlistContext.jsx` already call these exact endpoints. To wire the
watchlist UI to the real backend instead of localStorage, swap
`WatchlistContext.jsx`'s local state calls for the commented-out
`axiosClient` calls already sketched in that file.

## API reference

| Method | Endpoint | Auth | Body / Query | Notes |
|---|---|---|---|---|
| POST | `/api/auth/register.php` | – | `name, email, password, password_confirmation` | returns `{ token, user }` |
| POST | `/api/auth/login.php` | – | `email, password` | returns `{ token, user }` |
| POST | `/api/auth/logout.php` | Bearer | – | revokes current token |
| GET | `/api/auth/me.php` | Bearer | – | current user |
| GET | `/api/watchlists.php` | Bearer | – | `[{ id, name, stocks:[...] }]` |
| POST | `/api/watchlists.php` | Bearer | `name` | create a watchlist |
| DELETE | `/api/watchlists.php?id=` | Bearer | – | delete a watchlist |
| POST | `/api/watchlist_stocks.php` | Bearer | `watchlist_id, symbol, exchange` | add a stock |
| DELETE | `/api/watchlist_stocks.php?id=` | Bearer | – | remove a stock |
| POST | `/api/money/add.php` | Bearer | `amount` | demo stub |
| GET | `/api/market/quote.php?symbol=` | – | – | 501 stub, plug in a real provider |
| GET | `/api/market/movers.php` | – | – | 501 stub |
| GET | `/api/ipo/list.php` | – | – | 501 stub |

Send the token from login/register as `Authorization: Bearer <token>` — the
frontend's `axiosClient.js` interceptor already does this for you.

## CORS

`config/cors.php` allows `http://localhost:5173` and `http://127.0.0.1:5173`
(Vite's default dev server) out of the box, plus whatever you set as
`FRONTEND_URL` in `.env`. Add your deployed frontend origin there before going
to production.

## Notes / next steps

- Passwords are hashed with bcrypt via Laravel's `Hash` facade; tokens are
  Sanctum personal access tokens (no session cookies, no CSRF dance needed —
  simplest match for the frontend's Bearer-token `axiosClient.js`).
- `market/quote.php`, `market/movers.php`, and `ipo/list.php` return `501` on
  purpose — the React app already has a working live/simulated data source in
  `src/api/marketApi.js` (Twelve Data), so these are only here if you want to
  proxy or replace that from Laravel later.
- No LTS release currently exists in Laravel's versioning scheme (the last
  LTS major was Laravel 6); Laravel 12 was used here as the current
  well-supported release. Laravel 13 is the newest major if you want to track
  bleeding edge instead — just bump `laravel/framework` to `^13.0` in
  `composer.json` (requires PHP 8.3+).

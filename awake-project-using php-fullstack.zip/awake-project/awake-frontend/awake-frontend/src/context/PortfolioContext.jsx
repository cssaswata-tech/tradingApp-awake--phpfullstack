import { createContext, useCallback, useContext, useEffect, useState } from "react";
import axiosClient from "../api/axiosClient";
import { getQuote } from "../api/marketApi";
import { useAuth } from "./AuthContext";

const PortfolioContext = createContext(null);

// Real portfolio: holdings come from the Laravel /holdings.php endpoint
// (created by Buy orders in the Terminal). Current price for each holding
// is fetched live via getQuote() (Twelve Data if a key is set, otherwise
// a stable simulated quote) so Investment / Current Value / P&L on the
// Home page are computed from real numbers, not hardcoded text.
export function PortfolioProvider({ children }) {
  const { user, syncBalance } = useAuth();
  const [holdings, setHoldings] = useState([]);
  const [quotes, setQuotes] = useState({});
  const [loading, setLoading] = useState(false);

  const refresh = useCallback(async () => {
    if (!user) {
      setHoldings([]);
      return;
    }
    setLoading(true);
    try {
      const res = await axiosClient.get("/holdings.php");
      setHoldings(res.data || []);
    } catch (e) {
      setHoldings([]);
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  // Poll a live quote for every symbol currently held.
  useEffect(() => {
    if (!holdings.length) {
      setQuotes({});
      return;
    }
    let cancelled = false;

    async function loadQuotes() {
      const pairs = await Promise.all(
        holdings.map(async (h) => {
          try {
            const q = await getQuote(h.symbol, Number(h.avg_price) || 100);
            return [h.symbol, q];
          } catch {
            return [h.symbol, null];
          }
        })
      );
      if (!cancelled) setQuotes(Object.fromEntries(pairs));
    }

    loadQuotes();
    const id = setInterval(loadQuotes, 5000);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, [holdings]);

  // BUY: debits wallet + creates/increases a holding at a weighted avg price
  async function buy(symbol, exchange, quantity, price) {
    const res = await axiosClient.post("/holdings/buy.php", {
      symbol,
      exchange,
      quantity,
      price,
    });
    syncBalance(res.data.balance);
    await refresh();
    return res.data;
  }

  // SELL: credits wallet + reduces/removes the holding
  async function sell(symbol, quantity, price) {
    const res = await axiosClient.post("/holdings/sell.php", {
      symbol,
      quantity,
      price,
    });
    syncBalance(res.data.balance);
    await refresh();
    return res.data;
  }

  const investment = holdings.reduce(
    (sum, h) => sum + Number(h.quantity) * Number(h.avg_price),
    0
  );
  const currentValue = holdings.reduce((sum, h) => {
    const q = quotes[h.symbol];
    const price = q ? q.price : Number(h.avg_price);
    return sum + Number(h.quantity) * price;
  }, 0);
  const overallPL = currentValue - investment;
  const overallPLPct = investment ? (overallPL / investment) * 100 : 0;
  const todaysProfit = holdings.reduce((sum, h) => {
    const q = quotes[h.symbol];
    if (!q) return sum;
    return sum + Number(h.quantity) * q.change;
  }, 0);
  const prevValue = currentValue - todaysProfit;
  const todaysProfitPct = prevValue ? (todaysProfit / prevValue) * 100 : 0;

  return (
    <PortfolioContext.Provider
      value={{
        holdings,
        quotes,
        loading,
        investment,
        currentValue,
        overallPL,
        overallPLPct,
        todaysProfit,
        todaysProfitPct,
        refresh,
        buy,
        sell,
      }}
    >
      {children}
    </PortfolioContext.Provider>
  );
}

export const usePortfolio = () => useContext(PortfolioContext);

<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // php artisan db:seed to create a demo login:
        // \App\Models\User::factory()->create([
        //     'name' => 'Demo User',
        //     'email' => 'demo@example.com',
        //     'password' => bcrypt('password'),
        // ]);
    }
}

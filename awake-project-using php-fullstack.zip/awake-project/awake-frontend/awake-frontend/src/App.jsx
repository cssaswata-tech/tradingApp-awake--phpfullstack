import { useEffect, useState } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import Navbar from "./components/Navbar";
import MarketTicker from "./components/MarketTicker";
import MoneyModal from "./components/MoneyModal";
import Home from "./pages/Home";
import Terminal from "./pages/Terminal";
import Analyzer from "./pages/Analyzer";
import IPO from "./pages/IPO";
import Markets from "./pages/Markets";
import Login from "./pages/Login";
import Register from "./pages/Register";
import { useAuth } from "./context/AuthContext";

function Private({ children }) {
  const { user } = useAuth();
  return user ? children : <Navigate to="/login" />;
}

export default function App() {
  const { user } = useAuth();
  const [moneyOpen, setMoneyOpen] = useState(false);

  // The Money modal must never be visible to a logged-out visitor -- if it
  // was open and the user then logs out (or their session expires), close
  // it immediately rather than leaving it floating over the login page.
  useEffect(() => {
    if (!user) setMoneyOpen(false);
  }, [user]);

  function openMoney() {
    // Defense in depth: Navbar/Home already hide this trigger for guests,
    // but never open the modal for a logged-out user even if reached
    // some other way.
    if (user) setMoneyOpen(true);
  }

  return (
    <>
      <Navbar onOpenMoney={openMoney} />
      <MarketTicker />
      <Routes>
        <Route path="/" element={<Private><Home onOpenMoney={openMoney} /></Private>} />
        <Route path="/terminal" element={<Private><Terminal /></Private>} />
        <Route path="/terminal/:symbol" element={<Private><Terminal /></Private>} />
        <Route path="/analyzer" element={<Private><Analyzer /></Private>} />
        <Route path="/analyzer/:symbol" element={<Private><Analyzer /></Private>} />
        <Route path="/ipo" element={<Private><IPO /></Private>} />
        <Route path="/markets" element={<Private><Markets /></Private>} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
      {moneyOpen && user && <MoneyModal onClose={() => setMoneyOpen(false)} />}
    </>
  );
}
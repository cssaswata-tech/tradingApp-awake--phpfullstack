import { createContext, useContext, useState } from "react";
import axiosClient from "../api/axiosClient";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const raw = localStorage.getItem("awake_user");
    return raw ? JSON.parse(raw) : null;
  });
  const [error, setError] = useState("");
  const [balance, setBalance] = useState(() => {
    const raw = localStorage.getItem("awake_user");
    const u = raw ? JSON.parse(raw) : null;
    return Number(u?.balance ?? 0);
  });

  // Calls PHP: POST /auth/login.php -> { token, user }
  async function login(email, password) {
    setError("");
    try {
      const res = await axiosClient.post("/auth/login.php", { email, password });
      localStorage.setItem("awake_token", res.data.token);
      localStorage.setItem("awake_user", JSON.stringify(res.data.user));
      setUser(res.data.user);
      setBalance(Number(res.data.user?.balance ?? 0));
      return true;
    } catch (e) {
      setError(e.response?.data?.message || "Login failed. Is the PHP backend running?");
      return false;
    }
  }

  // Calls PHP: POST /auth/register.php -> { token, user }
  async function register(name, email, password) {
    setError("");
    try {
      const res = await axiosClient.post("/auth/register.php", { name, email, password });
      localStorage.setItem("awake_token", res.data.token);
      localStorage.setItem("awake_user", JSON.stringify(res.data.user));
      setUser(res.data.user);
      setBalance(Number(res.data.user?.balance ?? 0));
      return true;
    } catch (e) {
      setError(e.response?.data?.message || "Registration failed. Is the PHP backend running?");
      return false;
    }
  }

  function logout() {
    localStorage.removeItem("awake_token");
    localStorage.removeItem("awake_user");
    setUser(null);
    setBalance(0);
  }

  // Calls PHP: POST /money/add.php -> { amount, balance }
  // Requires an authenticated user (money must be persisted to the
  // database, never just kept in memory for a guest). If the backend
  // request itself fails while logged in (network hiccup), we fall back
  // to a local-only increment so the UI stays usable, but a logged-out
  // guest can never reach this at all -- addMoney throws instead of
  // silently pretending funds were added.
  async function addMoney(amount) {
    const amt = Number(amount);
    if (!amt || amt <= 0) return balance;

    if (!user) {
      throw new Error("You must be logged in to add money.");
    }

    try {
      const res = await axiosClient.post("/money/add.php", { amount: amt });
      const newBalance = Number(res.data.balance ?? balance + amt);
      const updatedUser = { ...user, balance: newBalance };
      localStorage.setItem("awake_user", JSON.stringify(updatedUser));
      setUser(updatedUser);
      setBalance(newBalance);
      return newBalance;
    } catch (e) {
      if (e.response) {
        // Backend reached but rejected the request (e.g. validation, auth
        // expired) -- surface it instead of silently pretending it worked.
        throw e;
      }
      // Backend unreachable (network/CORS) -- fall back to a local-only
      // increment so the UI stays usable; nothing is persisted server-side.
      const newBalance = balance + amt;
      const updatedUser = { ...user, balance: newBalance };
      localStorage.setItem("awake_user", JSON.stringify(updatedUser));
      setUser(updatedUser);
      setBalance(newBalance);
      return newBalance;
    }
  }

  // Lets other contexts (e.g. PortfolioContext after a buy/sell order)
  // sync the wallet balance without duplicating the add-funds flow.
  function syncBalance(newBalance) {
    const nb = Number(newBalance);
    setBalance(nb);
    if (user) {
      const updatedUser = { ...user, balance: nb };
      localStorage.setItem("awake_user", JSON.stringify(updatedUser));
      setUser(updatedUser);
    }
  }

  return (
    <AuthContext.Provider value={{ user, error, balance, login, register, logout, addMoney, syncBalance }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);

import { useState } from "react";
import { useNavigate } from "react-router-dom";
import useLiveData from "../hooks/useLiveData";
import { TRENDING, MOST_TRADED, MOST_BOUGHT_MTF } from "../api/mockData";

const TABS = {
  news: { label: "Stocks in News", data: TRENDING },
  traded: { label: "Most Traded", data: MOST_TRADED },
  mtf: { label: "Most Bought MTF", data: MOST_BOUGHT_MTF },
};

export default function TrendingStocks() {
  const [tab, setTab] = useState("news");
  const nav = useNavigate();
  const live = useLiveData(TABS[tab].data, 2500);

  return (
    <div className="card">
      <h3>Trending Stocks</h3>
      <div className="tabs-row">
        {Object.entries(TABS).map(([key, { label }]) => (
          <button key={key} className={tab === key ? "active" : ""} onClick={() => setTab(key)}>
            {label}
          </button>
        ))}
      </div>
      {live.map((s) => (
        <div className="stock-item" key={s.symbol}>
          <div className="name" onClick={() => nav(`/terminal/${s.symbol}`)}>{s.name}<small>{s.exchange}</small></div>
          <div className="price">
            <div className={s.change >= 0 ? "up" : "down"}>{s.price.toFixed(2)}</div>
            <small className={s.change >= 0 ? "up" : "down"}>{s.change >= 0 ? "+" : ""}{s.change.toFixed(2)} ({s.changePct.toFixed(2)}%)</small>
          </div>
        </div>
      ))}
    </div>
  );
}

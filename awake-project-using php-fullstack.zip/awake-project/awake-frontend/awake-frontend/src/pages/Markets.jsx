import { useMemo, useState } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import {
  SEED_STOCKS, ETF_LIST, MF_LIST, FUTURES_LIST, COMMODITIES_LIST,
  RENT_STOCKS_LIST, GOLD_VAULT, OPTIONS_UNDERLYINGS, buildOptionChain,
} from "../api/mockData";
import useLiveData from "../hooks/useLiveData";

const TABS = [
  { id: "equities", label: "Equities" },
  { id: "mf", label: "Mutual Funds" },
  { id: "etf", label: "ETFs" },
  { id: "options", label: "Options" },
  { id: "futures", label: "Futures" },
  { id: "commodities", label: "Commodities" },
  { id: "rent-stocks", label: "Rent Stocks" },
  { id: "gold-vault", label: "Gold Vault" },
];

function PriceRow({ s, nav }) {
  return (
    <div className="stock-item" key={s.symbol}>
      <div className="name" onClick={() => nav(`/terminal/${s.symbol}`)}>
        {s.name}<small>{s.exchange}</small>
      </div>
      <div className="price">
        <div className={s.change >= 0 ? "up" : "down"}>{s.price.toFixed(2)}</div>
        <small className={s.change >= 0 ? "up" : "down"}>{s.change >= 0 ? "+" : ""}{s.change.toFixed(2)} ({s.changePct.toFixed(2)}%)</small>
      </div>
    </div>
  );
}

function EquitiesTab({ nav }) {
  const live = useLiveData(SEED_STOCKS, 2000);
  return <>{live.map((s) => <PriceRow key={s.symbol} s={s} nav={nav} />)}</>;
}

function EtfTab({ nav }) {
  const live = useLiveData(ETF_LIST, 2500);
  return <>{live.map((s) => <PriceRow key={s.symbol} s={s} nav={nav} />)}</>;
}

function MfTab() {
  return (
    <table className="data-table">
      <thead><tr><th>Fund</th><th>Category</th><th>NAV</th><th>1Y Return</th><th>Risk</th></tr></thead>
      <tbody>
        {MF_LIST.map((f) => (
          <tr key={f.symbol}>
            <td>{f.name}</td>
            <td>{f.category}</td>
            <td>₹{f.nav.toFixed(2)}</td>
            <td className="up">+{f.oneYearReturn}%</td>
            <td>{f.risk}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function FuturesTab({ nav }) {
  const live = useLiveData(FUTURES_LIST.map((f) => ({ ...f, exchange: "NSE" })), 2500);
  return (
    <table className="data-table">
      <thead><tr><th>Contract</th><th>Expiry</th><th>LTP</th><th>Chg%</th><th>OI</th><th>Lot</th></tr></thead>
      <tbody>
        {live.map((f) => (
          <tr key={f.symbol} className="clickable" onClick={() => nav(`/terminal/${f.symbol}`)}>
            <td>{f.symbol}<br /><small style={{ color: "var(--muted)" }}>{f.underlying}</small></td>
            <td>{f.expiry}</td>
            <td>{f.price.toFixed(2)}</td>
            <td className={f.change >= 0 ? "up" : "down"}>{f.change >= 0 ? "+" : ""}{f.changePct.toFixed(2)}%</td>
            <td>{f.oi}</td>
            <td>{f.lotSize}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function CommoditiesTab({ nav }) {
  const live = useLiveData(COMMODITIES_LIST, 2500);
  return <>{live.map((s) => <PriceRow key={s.symbol} s={s} nav={nav} />)}</>;
}

function OptionsTab() {
  const [underlying, setUnderlying] = useState(OPTIONS_UNDERLYINGS[0]);
  const spot = underlying === "NIFTY 50" ? 24192 : underlying === "NIFTY BANK" ? 57971 : 3121;
  const chain = useMemo(() => buildOptionChain(spot), [underlying]);
  return (
    <div>
      <div className="tabs-row">
        {OPTIONS_UNDERLYINGS.map((u) => (
          <button key={u} className={u === underlying ? "active" : ""} onClick={() => setUnderlying(u)}>{u}</button>
        ))}
      </div>
      <table className="data-table option-chain">
        <thead>
          <tr><th colSpan={3}>CALLS</th><th>STRIKE</th><th colSpan={3}>PUTS</th></tr>
          <tr><th>OI</th><th>IV</th><th>LTP</th><th></th><th>LTP</th><th>IV</th><th>OI</th></tr>
        </thead>
        <tbody>
          {chain.map((r) => (
            <tr key={r.strike}>
              <td>{r.callOI.toLocaleString()}</td>
              <td>{r.callIV}%</td>
              <td className="up">{r.callLTP}</td>
              <td className="strike">{r.strike}</td>
              <td className="down">{r.putLTP}</td>
              <td>{r.putIV}%</td>
              <td>{r.putOI.toLocaleString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function RentStocksTab() {
  return (
    <table className="data-table">
      <thead><tr><th>Stock</th><th>Lending Rate (p.a.)</th><th>Demand</th><th>Min Qty</th><th></th></tr></thead>
      <tbody>
        {RENT_STOCKS_LIST.map((r) => (
          <tr key={r.symbol}>
            <td>{r.name}</td>
            <td className="up">{r.lendingRatePct}%</td>
            <td>{r.demandLabel}</td>
            <td>{r.minQty}</td>
            <td><button className="btn secondary">Lend</button></td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function GoldVaultTab() {
  const g = GOLD_VAULT;
  return (
    <div>
      <p style={{ color: "var(--muted)" }}>{g.purity} pure gold & silver · {g.storage}</p>
      <div className="stat-grid">
        <div><label>Gold Buy (₹/g)</label><div className="val up">₹{g.goldBuy}</div></div>
        <div><label>Gold Sell (₹/g)</label><div className="val">₹{g.goldSell}</div></div>
        <div><label>Silver Buy (₹/g)</label><div className="val up">₹{g.silverBuy}</div></div>
        <div><label>Silver Sell (₹/g)</label><div className="val">₹{g.silverSell}</div></div>
      </div>
      <div style={{ display: "flex", gap: 10, marginTop: 6 }}>
        <button className="btn">Buy Gold</button>
        <button className="btn secondary">Buy Silver</button>
      </div>
    </div>
  );
}

export default function Markets() {
  const [params, setParams] = useSearchParams();
  const tab = params.get("tab") || "equities";
  const nav = useNavigate();

  return (
    <div className="layout" style={{ gridTemplateColumns: "1fr" }}>
      <div className="card">
        <div className="tabs-row">
          {TABS.map((t) => (
            <button key={t.id} className={t.id === tab ? "active" : ""} onClick={() => setParams({ tab: t.id })}>
              {t.label}
            </button>
          ))}
        </div>
        {tab === "equities" && <EquitiesTab nav={nav} />}
        {tab === "etf" && <EtfTab nav={nav} />}
        {tab === "mf" && <MfTab />}
        {tab === "futures" && <FuturesTab nav={nav} />}
        {tab === "commodities" && <CommoditiesTab nav={nav} />}
        {tab === "options" && <OptionsTab />}
        {tab === "rent-stocks" && <RentStocksTab />}
        {tab === "gold-vault" && <GoldVaultTab />}
      </div>
    </div>
  );
}

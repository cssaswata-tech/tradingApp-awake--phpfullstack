import { useState } from "react";
import { usePortfolio } from "../context/PortfolioContext";
import { useAuth } from "../context/AuthContext";

// side: "buy" | "sell". price is the live price shown in the Terminal at
// the moment the button was clicked (used as the execution price for this
// simulated order — there's no real exchange/broker connected).
export default function BuySellModal({ side, symbol, exchange, price, onClose }) {
  const { buy, sell } = usePortfolio();
  const { balance } = useAuth();
  const [qty, setQty] = useState(1);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [done, setDone] = useState(false);

  const total = Number(qty || 0) * price;

  async function submit() {
    setError("");
    if (!qty || Number(qty) <= 0) {
      setError("Enter a valid quantity.");
      return;
    }
    setSubmitting(true);
    try {
      if (side === "buy") {
        await buy(symbol, exchange, Number(qty), price);
      } else {
        await sell(symbol, Number(qty), price);
      }
      setDone(true);
    } catch (e) {
      setError(e.response?.data?.message || `${side === "buy" ? "Buy" : "Sell"} order failed.`);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <button className="close" onClick={onClose}>✕</button>
        <h3>{side === "buy" ? "Buy" : "Sell"} {symbol}</h3>

        {done ? (
          <>
            <p>
              Order executed: {side === "buy" ? "bought" : "sold"} {qty} share{Number(qty) === 1 ? "" : "s"} of {symbol} at ₹{price.toFixed(2)}.
            </p>
            <p style={{ color: "var(--muted)" }}>
              New wallet balance: ₹{Number(balance).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </p>
            <div className="actions">
              <button className="btn" onClick={onClose}>Done</button>
            </div>
          </>
        ) : (
          <>
            <p style={{ color: "var(--muted)", marginTop: -6 }}>
              Wallet balance: ₹{Number(balance).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              {" · "}Market price: ₹{price.toFixed(2)}
            </p>
            <label style={{ fontSize: 12, color: "var(--muted)" }}>Quantity</label>
            <input
              type="number"
              min="1"
              step="1"
              value={qty}
              onChange={(e) => setQty(e.target.value)}
            />
            <p style={{ color: "var(--muted)" }}>
              {side === "buy" ? "Total cost" : "Total proceeds"}: ₹
              {total.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </p>
            {error && <p className="down" style={{ fontSize: 13 }}>{error}</p>}
            <div className="actions">
              <button className="btn secondary" onClick={onClose}>Cancel</button>
              <button className="btn" disabled={submitting} onClick={submit}>
                {submitting ? "Placing..." : side === "buy" ? "Buy" : "Sell"}
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

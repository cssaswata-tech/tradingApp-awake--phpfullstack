<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class MoneyController extends Controller
{
    // POST /api/money/add.php { amount } -> { message, amount, balance }
    // Credits the authenticated user's wallet balance.
    // NOTE: this is a demo ledger only — no real payment gateway is wired
    // in, so it does not move real money. Plug in a gateway (Razorpay,
    // Stripe, etc.) here before accepting real funds.
    public function add(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'amount' => ['required', 'numeric', 'min:1'],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'message' => $validator->errors()->first(),
                'errors' => $validator->errors(),
            ], 422);
        }

        $user = $request->user();
        $amount = (float) $request->amount;

        $user->balance = (float) $user->balance + $amount;
        $user->save();

        return response()->json([
            'message' => 'Funds added to wallet.',
            'amount' => $amount,
            'balance' => (float) $user->balance,
        ]);
    }

    // GET /api/money/balance.php -> { balance }
    public function balance(Request $request)
    {
        return response()->json([
            'balance' => (float) $request->user()->balance,
        ]);
    }
}

<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class MarketController extends Controller
{
    // GET /api/market/quote.php?symbol=TCS
    // Stub only — the React app already has a working Twelve Data / simulated
    // fallback in src/api/marketApi.js. Wire this up to a real provider
    // (or proxy Twelve Data server-side) if you want quotes to come from Laravel.
    public function quote(Request $request)
    {
        $symbol = strtoupper($request->query('symbol', 'TCS'));

        return response()->json([
            'symbol' => $symbol,
            'price' => null,
            'message' => 'Implement this endpoint with a real market data provider.',
        ], 501);
    }

    // GET /api/market/movers.php
    public function movers(Request $request)
    {
        return response()->json([
            'gainers' => [],
            'losers' => [],
            'mostTraded' => [],
            'message' => 'Implement this endpoint with a real market data provider.',
        ], 501);
    }
}

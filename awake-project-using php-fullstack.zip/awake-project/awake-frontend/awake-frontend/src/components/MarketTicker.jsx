import useLiveData from "../hooks/useLiveData";
import { INDICES } from "../api/mockData";

export default function MarketTicker() {
  const live = useLiveData(INDICES, 2500);
  return (
    <div className="ticker">
      {live.map((idx) => (
        <div className="item" key={idx.symbol}>
          <b>{idx.name}</b>
          {idx.price.toLocaleString(undefined, { maximumFractionDigits: 2 })}{" "}
          <span className={idx.change >= 0 ? "up" : "down"}>
            {idx.change >= 0 ? "+" : ""}{idx.change.toFixed(2)} ({idx.changePct.toFixed(2)}%)
          </span>
        </div>
      ))}
    </div>
  );
}

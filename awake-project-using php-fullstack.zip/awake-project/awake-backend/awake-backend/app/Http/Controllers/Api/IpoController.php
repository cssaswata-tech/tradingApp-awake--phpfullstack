<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;

class IpoController extends Controller
{
    // GET /api/ipo/list.php
    public function index()
    {
        return response()->json([
            'ipos' => [],
            'message' => 'Implement this endpoint with a real IPO data source.',
        ], 501);
    }
}

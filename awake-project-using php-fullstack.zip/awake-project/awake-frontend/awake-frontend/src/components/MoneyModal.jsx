import { useState } from "react";
import { useAuth } from "../context/AuthContext";

export default function MoneyModal({ onClose }) {
  const { addMoney, balance } = useAuth();
  const [amount, setAmount] = useState("");
  const [done, setDone] = useState(false);
  const [newBalance, setNewBalance] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  async function addFunds() {
    if (!amount || Number(amount) <= 0) return;
    setError("");
    setSubmitting(true);
    try {
      const result = await addMoney(amount);
      setNewBalance(result);
      setDone(true);
    } catch (e) {
      setError(e.response?.data?.message || e.message || "Could not add money. Please try again.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <button className="close" onClick={onClose}>✕</button>
        <h3>Add Money</h3>
        {done ? (
          <>
            <p>₹{Number(amount).toLocaleString("en-IN")} added successfully.</p>
            <p style={{ color: "var(--muted)" }}>
              New wallet balance: ₹{Number(newBalance).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </p>
            <div className="actions">
              <button className="btn" onClick={onClose}>Done</button>
            </div>
          </>
        ) : (
          <>
            <p style={{ color: "var(--muted)", marginTop: -6 }}>
              Current balance: ₹{Number(balance).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </p>
            <input
              type="number"
              placeholder="Enter amount (₹)"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
            {error && <p className="down" style={{ fontSize: 13 }}>{error}</p>}
            <div className="actions">
              <button className="btn secondary" onClick={onClose}>Cancel</button>
              <button className="btn" disabled={submitting} onClick={addFunds}>
                {submitting ? "Adding..." : "Add Money"}
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { getCandles, HAS_LIVE_KEY } from "../api/marketApi";
import { analyzeSymbol } from "../lib/analyzer";
import { SEED_STOCKS } from "../api/mockData";

const VERDICT_COLOR = { BUY: "up", SELL: "down", HOLD: "" };
// Backend that holds the OpenAI key server-side (see /server in the repo
// root). Never call OpenAI directly from this component — see README.
const BACKEND_URL = import.meta.env.VITE_BACKEND_URL || "http://localhost:5000";

export default function Analyzer() {
  const { symbol: routeSymbol } = useParams();
  const nav = useNavigate();
  const [input, setInput] = useState(routeSymbol || "TCS");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [source, setSource] = useState(null);
  const [error, setError] = useState(null);
  const [explanation, setExplanation] = useState(null);
  const [explainLoading, setExplainLoading] = useState(false);
  const [explainError, setExplainError] = useState(null);

  async function getAiExplanation() {
    if (!result) return;
    setExplainLoading(true);
    setExplainError(null);
    setExplanation(null);
    try {
      const res = await fetch(`${BACKEND_URL}/api/explain`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          symbol: routeSymbol || input.toUpperCase(),
          verdict: result.verdict,
          score: result.score,
          confidence: result.confidence,
          signals: result.signals,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Request failed");
      setExplanation(data.explanation);
    } catch (e) {
      setExplainError("Couldn't reach the AI explanation backend. Is `server/` running (npm start in /server)?");
    } finally {
      setExplainLoading(false);
    }
  }

  async function run(sym) {
    setLoading(true);
    setError(null);
    try {
      const hint = SEED_STOCKS.find((s) => s.symbol === sym)?.price || 100 + (sym.charCodeAt(0) % 20) * 40;
      const { candles, source: src } = await getCandles(sym, { basePriceHint: hint });
      const analysis = analyzeSymbol(candles);
      setResult(analysis);
      setSource(src);
    } catch (e) {
      setError("Couldn't analyze that symbol. Try another.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { run(routeSymbol || input); /* eslint-disable-next-line */ }, [routeSymbol]);

  function onSubmit(e) {
    e.preventDefault();
    const sym = input.trim().toUpperCase();
    if (!sym) return;
    nav(`/analyzer/${sym}`);
    run(sym);
  }

  return (
    <div className="layout" style={{ gridTemplateColumns: "1fr" }}>
      <div className="card">
        <h3>AI Stock Analyzer</h3>
        <p style={{ color: "var(--muted)", marginTop: -6 }}>
          Enter any symbol — the engine scores trend, momentum, volatility and volume signals
          from real technical-analysis math and gives you a BUY / HOLD / SELL call with its reasoning.
          {!HAS_LIVE_KEY && " Currently running on simulated price history — add VITE_TWELVEDATA_KEY in .env for live data."}
        </p>
        <form className="search" onSubmit={onSubmit} style={{ marginBottom: 4 }}>
          🔍 <input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Enter symbol e.g. TCS, RELIANCE, INFY" />
          <button className="btn" type="submit">Analyze</button>
        </form>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
          {SEED_STOCKS.slice(0, 6).map((s) => (
            <button key={s.symbol} className="chip" onClick={() => { setInput(s.symbol); nav(`/analyzer/${s.symbol}`); run(s.symbol); }}>
              {s.symbol}
            </button>
          ))}
        </div>
      </div>

      {loading && <div className="card">Analyzing…</div>}
      {error && <div className="card down">{error}</div>}

      {result && !loading && (
        <>
          <div className="card verdict-card">
            <div>
              <div style={{ color: "var(--muted)", fontSize: 13 }}>
                {routeSymbol || input.toUpperCase()} · {source === "live" ? "Live data" : "Simulated data"} · Price ₹{result.price.toFixed(2)}
              </div>
              <div className={`verdict-badge ${VERDICT_COLOR[result.verdict]}`}>{result.verdict}</div>
            </div>
            <div className="verdict-meta">
              <div><label>Confidence</label><div className="val">{result.confidence}%</div></div>
              <div><label>Composite Score</label><div className={`val ${result.score >= 0 ? "up" : "down"}`}>{result.score > 0 ? "+" : ""}{result.score}</div></div>
              <div><label>Trend Strength (ADX)</label><div className="val">{result.trendStrength ?? "—"}</div></div>
            </div>
          </div>

          <div className="card">
            <h3>Why this call</h3>
            {result.signals.map((s, i) => (
              <div className="signal-row" key={i}>
                <span className={s.score > 0 ? "up" : s.score < 0 ? "down" : ""}>
                  {s.score > 0 ? "▲" : s.score < 0 ? "▼" : "•"}
                </span>
                <div>
                  <b>{s.label}</b>
                  <div style={{ color: "var(--muted)", fontSize: 13 }}>{s.reason}</div>
                </div>
              </div>
            ))}
          </div>

          <div className="card">
            <div className="row-between">
              <h3>AI Explanation</h3>
              <button className="btn secondary" onClick={getAiExplanation} disabled={explainLoading}>
                {explainLoading ? "Thinking…" : "🤖 Get AI Explanation"}
              </button>
            </div>
            <p style={{ color: "var(--muted)", fontSize: 13, marginTop: -4 }}>
              Turns the signals above into a plain-English summary via a backend that holds the OpenAI key
              server-side (see <code>/server</code>). It only rephrases the existing verdict — it doesn't
              re-decide BUY/HOLD/SELL.
            </p>
            {explainError && <p className="down" style={{ fontSize: 13 }}>{explainError}</p>}
            {explanation && <p style={{ lineHeight: 1.6 }}>{explanation}</p>}
          </div>

          <div className="card">
            <div className="row-between">
              <h3>Key Indicators</h3>
              <button className="btn secondary" onClick={() => nav(`/terminal/${routeSymbol || input.toUpperCase()}`)}>Open in Terminal</button>
            </div>
            <div className="indicator-grid">
              {result.indicators.filter((i) => ["sma20","sma50","sma200","rsi14","macd_line","atr14","adx14","cci20"].includes(i.id)).map((i) => (
                <div key={i.id}>
                  <label>{i.label}</label>
                  <div className="val">{i.latest != null ? i.latest.toFixed(2) : "—"}</div>
                </div>
              ))}
            </div>
          </div>

          <p style={{ color: "var(--muted)", fontSize: 12, padding: "0 4px" }}>
            This is algorithmic technical analysis, not financial advice. Markets carry risk — do your own research before trading.
          </p>
        </>
      )}
    </div>
  );
}

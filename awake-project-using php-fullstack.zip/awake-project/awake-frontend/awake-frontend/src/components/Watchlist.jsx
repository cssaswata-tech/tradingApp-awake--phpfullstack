import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useWatchlist } from "../context/WatchlistContext";
import { NIFTY500_UNIQUE } from "../api/nifty500";
import useLiveData from "../hooks/useLiveData";

export default function Watchlist() {
  const { watchlists, createWatchlist, deleteWatchlist, addStock, removeStock } = useWatchlist();
  const [activeId, setActiveId] = useState(watchlists[0]?.id);

  // Inline "new watchlist" row -- no window.prompt() alert box.
  const [showNewList, setShowNewList] = useState(false);
  const [newListName, setNewListName] = useState("");

  // Inline "add stock" row, searchable across the full Nifty 500 universe.
  const [showAdd, setShowAdd] = useState(false);
  const [stockQuery, setStockQuery] = useState("");

  const nav = useNavigate();

  const active = watchlists.find((w) => w.id === activeId) || watchlists[0];
  const liveStocks = useLiveData(active ? active.stocks : [], 2000);

  const stockMatches = useMemo(() => {
    const q = stockQuery.trim().toLowerCase();
    if (!q) return NIFTY500_UNIQUE.slice(0, 20);
    return NIFTY500_UNIQUE.filter(
      (s) => s.symbol.toLowerCase().includes(q) || s.name.toLowerCase().includes(q)
    ).slice(0, 20);
  }, [stockQuery]);

  async function handleCreateList() {
    const name = newListName.trim();
    if (!name) return;
    const wl = await createWatchlist(name);
    setActiveId(wl.id);
    setNewListName("");
    setShowNewList(false);
  }

  async function handleAddStock(s) {
    await addStock(active.id, s);
    setShowAdd(false);
    setStockQuery("");
  }

  // READ: clicking a stock name opens the live terminal for it
  function openTerminal(symbol) {
    nav(`/terminal/${symbol}`);
  }

  if (!active) {
    return (
      <div className="card">
        <h3>My Watchlists</h3>
        <p style={{ color: "var(--muted)" }}>You don't have any watchlists yet.</p>
        {!showNewList ? (
          <button className="btn" onClick={() => setShowNewList(true)}>+ Create a watchlist</button>
        ) : (
          <div className="add-stock-row">
            <input
              autoFocus
              placeholder="Watchlist name"
              value={newListName}
              onChange={(e) => setNewListName(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleCreateList()}
            />
            <button className="btn" onClick={handleCreateList}>Create</button>
            <button className="btn secondary" onClick={() => { setShowNewList(false); setNewListName(""); }}>Cancel</button>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="card">
      <div className="row-between">
        <h3>My Watchlists</h3>
        <button className="btn secondary" onClick={() => deleteWatchlist(active.id)}>
          Delete list
        </button>
      </div>

      <div className="wl-tabs">
        {watchlists.map((w) => (
          <button key={w.id} className={w.id === active.id ? "active" : ""} onClick={() => setActiveId(w.id)}>
            {w.name}
          </button>
        ))}
        {!showNewList ? (
          <button className="new" onClick={() => setShowNewList(true)}>+ New</button>
        ) : (
          <div className="add-stock-row" style={{ marginLeft: 6 }}>
            <input
              autoFocus
              placeholder="Watchlist name"
              value={newListName}
              onChange={(e) => setNewListName(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleCreateList()}
            />
            <button className="btn" onClick={handleCreateList}>Create</button>
            <button className="btn secondary" onClick={() => { setShowNewList(false); setNewListName(""); }}>Cancel</button>
          </div>
        )}
      </div>

      <div className="search">
        🔍 <input placeholder="Search for companies to invest or trade" />
      </div>

      {liveStocks.map((s) => (
        <div className="stock-item" key={s.id}>
          <div className="name" onClick={() => openTerminal(s.symbol)}>
            {s.name}
            <small>{s.exchange}</small>
          </div>
          <div className="row-between" style={{ gap: 6 }}>
            <div className="price">
              <div className={s.change >= 0 ? "up" : "down"}>{s.price.toFixed(2)}</div>
              <small className={s.change >= 0 ? "up" : "down"}>
                {s.change >= 0 ? "+" : ""}{s.change.toFixed(2)} ({s.changePct.toFixed(2)}%)
              </small>
            </div>
            <button className="del" title="Remove from watchlist" onClick={() => removeStock(active.id, s.id)}>✕</button>
          </div>
        </div>
      ))}

      {!showAdd ? (
        <button className="btn" style={{ marginTop: 12 }} onClick={() => setShowAdd(true)}>
          + Add stock
        </button>
      ) : (
        <div style={{ marginTop: 12 }}>
          <div className="add-stock-row">
            <input
              autoFocus
              placeholder="Search Nifty 500 stocks (name or symbol)..."
              value={stockQuery}
              onChange={(e) => setStockQuery(e.target.value)}
            />
            <button className="btn secondary" onClick={() => { setShowAdd(false); setStockQuery(""); }}>Cancel</button>
          </div>
          <div className="wl-tabs" style={{ flexWrap: "wrap", marginTop: 8 }}>
            {stockMatches.map((s) => (
              <button key={s.symbol} onClick={() => handleAddStock(s)} title={s.name}>
                {s.symbol}
              </button>
            ))}
            {stockMatches.length === 0 && (
              <span style={{ color: "var(--muted)" }}>No matches.</span>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

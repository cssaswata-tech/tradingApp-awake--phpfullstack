import { useEffect, useRef, useState } from "react";

// Simulates a live price feed by randomly nudging prices every tick.
// SWAP FOR REAL DATA: replace the interval body with
//   axiosClient.get(`/market/quote.php?symbol=${symbol}`)
// and setItems(res.data) on an interval or a WebSocket message handler.
export default function useLiveData(seedItems, intervalMs = 2000) {
  const [items, setItems] = useState(seedItems);
  const ref = useRef(seedItems);

  useEffect(() => {
    ref.current = seedItems;
    setItems(seedItems);
  }, [seedItems]);

  useEffect(() => {
    const id = setInterval(() => {
      setItems((prev) =>
        prev.map((it) => {
          const drift = (Math.random() - 0.5) * (it.price * 0.004);
          const price = Math.max(0.05, it.price + drift);
          const change = it.change + drift;
          const prevPrice = price - change;
          const changePct = prevPrice ? (change / prevPrice) * 100 : 0;
          return { ...it, price: +price.toFixed(2), change: +change.toFixed(2), changePct: +changePct.toFixed(2) };
        })
      );
    }, intervalMs);
    return () => clearInterval(id);
  }, [intervalMs]);

  return items;
}

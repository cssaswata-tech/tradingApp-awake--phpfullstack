import { useNavigate } from "react-router-dom";
import Watchlist from "../components/Watchlist";
import InvestTradeLinks from "../components/InvestTradeLinks";
import MarketMovers from "../components/MarketMovers";
import TrendingStocks from "../components/TrendingStocks";
import { usePortfolio } from "../context/PortfolioContext";

function inr(n) {
  return Number(n || 0).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export default function Home({ onOpenMoney }) {
  const nav = useNavigate();
  const {
    holdings,
    quotes,
    loading,
    investment,
    currentValue,
    overallPL,
    overallPLPct,
    todaysProfit,
    todaysProfitPct,
  } = usePortfolio();

  const hasHoldings = holdings.length > 0;

  return (
    <div className="layout">
      <Watchlist />
      <div>
        <div className="card">
          <div className="row-between">
            <h3>My Portfolio</h3>
          </div>
          {loading ? (
            <p style={{ color: "var(--muted)" }}>Loading portfolio…</p>
          ) : !hasHoldings ? (
            <p style={{ color: "var(--muted)" }}>
              You don't own any stocks yet. Buy from the Terminal to start building your portfolio.
            </p>
          ) : (
            <>
              <div className="stat-grid">
                <div><label>Investment</label><div className="val">₹{inr(investment)}</div></div>
                <div><label>Current Value</label><div className="val">₹{inr(currentValue)}</div></div>
                <div>
                  <label>Overall {overallPL >= 0 ? "Profit" : "Loss"}</label>
                  <div className={`val ${overallPL >= 0 ? "up" : "down"}`}>
                    {overallPL >= 0 ? "+" : "-"}₹{inr(Math.abs(overallPL))} ({overallPLPct.toFixed(2)}%)
                  </div>
                </div>
                <div>
                  <label>Today's Profit</label>
                  <div className={`val ${todaysProfit >= 0 ? "up" : "down"}`}>
                    {todaysProfit >= 0 ? "+" : "-"}₹{inr(Math.abs(todaysProfit))} ({todaysProfitPct.toFixed(2)}%)
                  </div>
                </div>
              </div>

              <div style={{ marginTop: 18 }}>
                <div className="row-between" style={{ marginBottom: 6 }}>
                  <h4 style={{ margin: 0 }}>Holdings ({holdings.length})</h4>
                </div>
                {holdings.map((h) => {
                  const q = quotes[h.symbol];
                  const ltp = q ? q.price : Number(h.avg_price);
                  const qty = Number(h.quantity);
                  const avg = Number(h.avg_price);
                  const invested = qty * avg;
                  const curVal = qty * ltp;
                  const pl = curVal - invested;
                  const plPct = invested ? (pl / invested) * 100 : 0;
                  return (
                    <div
                      key={h.id}
                      className="stock-item"
                      style={{ cursor: "pointer" }}
                      onClick={() => nav(`/terminal/${h.symbol}`)}
                    >
                      <div className="name">
                        {h.symbol}
                        <small>{h.exchange} · {qty} qty @ avg ₹{avg.toFixed(2)}</small>
                      </div>
                      <div className="price">
                        <div>₹{ltp.toFixed(2)}</div>
                        <small className={pl >= 0 ? "up" : "down"}>
                          {pl >= 0 ? "+" : "-"}₹{inr(Math.abs(pl))} ({plPct.toFixed(2)}%)
                        </small>
                      </div>
                    </div>
                  );
                })}
              </div>
            </>
          )}
        </div>
        <div style={{ height: 16 }} />
        <InvestTradeLinks onOpenMoney={onOpenMoney} />
        <div style={{ height: 16 }} />
        <TrendingStocks />
      </div>
      <MarketMovers />
    </div>
  );
}

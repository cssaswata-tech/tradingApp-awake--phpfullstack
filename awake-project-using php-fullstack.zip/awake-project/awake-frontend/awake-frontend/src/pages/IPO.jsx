import { LATEST_IPOS } from "../api/mockData";

// SWAP FOR REAL DATA: axiosClient.get("/ipo/list.php").then(res => setIpos(res.data))
export default function IPO() {
  return (
    <div className="layout" style={{ gridTemplateColumns: "1fr" }}>
      <div className="card">
        <h3>Latest IPOs</h3>
        {LATEST_IPOS.map((ipo) => (
          <div className="ipo-card" key={ipo.name}>
            <div>
              <div><b>{ipo.name}</b></div>
              <small style={{ color: "var(--muted)" }}>{ipo.type} • Price band {ipo.priceBand} • {ipo.open} to {ipo.close}</small>
            </div>
            <div style={{ textAlign: "right" }}>
              <span className={`badge ${ipo.status}`}>{ipo.status}</span>
              {ipo.listingGain && <div className="up" style={{ marginTop: 4 }}>{ipo.listingGain}</div>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;

class StockController extends Controller
{
    // GET /api/stocks/nifty500.php?q=tcs -> [{ symbol, name, exchange }, ...]
    //
    // Serves the Nifty 500 stock universe used to populate watchlist search,
    // "add stock" pickers, and the terminal's quick-jump chips.
    //
    // This ships with a large practical working set (~240 real NSE symbols
    // across sectors) rather than a byte-for-byte copy of NSE's official
    // 500-row constituent file, since that file changes every semi-annual
    // rebalance. To load the *exact* current list instead:
    //   1. Download the latest CSV from
    //      https://www.niftyindices.com/IndexConstituent/ind_nifty500list.csv
    //   2. Convert each row's Symbol + Company Name into
    //      { "symbol": "...", "name": "...", "exchange": "NSE" }
    //   3. Replace resources/data/nifty500.json with the result
    // No other code changes needed — the frontend calls this same endpoint.
    public function index(Request $request)
    {
        $path = resource_path('data/nifty500.json');
        $stocks = File::exists($path) ? json_decode(File::get($path), true) : [];

        $q = strtolower((string) $request->query('q', ''));
        if ($q !== '') {
            $stocks = array_values(array_filter($stocks, function ($s) use ($q) {
                return str_contains(strtolower($s['symbol']), $q)
                    || str_contains(strtolower($s['name']), $q);
            }));
        }

        return response()->json($stocks);
    }
}

<?php

return [
    // Applies to every API route (all our routes live under /api).
    'paths' => ['api/*', 'sanctum/csrf-cookie'],

    'allowed_methods' => ['*'],

    // Add your deployed frontend URL(s) here alongside the local Vite server.
    'allowed_origins' => array_filter([
        'http://localhost:5173',
        'http://127.0.0.1:5173',
        env('FRONTEND_URL'),
    ]),

    'allowed_origins_patterns' => [],

    'allowed_headers' => ['*'],

    'exposed_headers' => [],

    'max_age' => 0,

    // We use Bearer-token auth (Sanctum personal access tokens), not cookies,
    // so this can stay false. Flip to true only if you switch to SPA cookie auth.
    'supports_credentials' => false,
];

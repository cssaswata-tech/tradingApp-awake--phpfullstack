import express from "express";
import cors from "cors";
import "dotenv/config";

const app = express();
app.use(express.json());
app.use(cors({ origin: (process.env.CORS_ORIGIN || "http://localhost:5173").split(",") }));

const OPENAI_KEY = process.env.OPENAI_API_KEY;

// POST /api/explain
// Body: { symbol, verdict, score, confidence, signals: [{label, score, reason}] }
// Returns: { explanation: string }
//
// The technical-analysis math (BUY/HOLD/SELL, every signal and reason) is
// already computed on the frontend in src/lib/analyzer.js — this endpoint
// does NOT re-decide the verdict. It only asks the model to turn the
// already-computed signals into a short, readable paragraph. That keeps
// the actual trading logic auditable and out of the LLM's hands.
app.post("/api/explain", async (req, res) => {
  if (!OPENAI_KEY) {
    return res.status(500).json({ error: "Server is missing OPENAI_API_KEY. Add it to server/.env." });
  }

  const { symbol, verdict, score, confidence, signals } = req.body || {};
  if (!symbol || !verdict || !Array.isArray(signals)) {
    return res.status(400).json({ error: "Missing symbol, verdict, or signals." });
  }

  const signalLines = signals
    .slice(0, 12)
    .map((s) => `- ${s.label}: ${s.reason}`)
    .join("\n");

  const prompt = `You are explaining a technical-analysis stock signal to a retail investor.
Symbol: ${symbol}
Verdict: ${verdict} (composite score ${score}, confidence ${confidence}%)
Signals already computed by a rules engine (do not change or contradict these):
${signalLines}

Write a plain-English explanation in 3-5 sentences. Mention the strongest 2-3 signals driving the call. End with one sentence reminding the reader this is not financial advice.`;

  try {
    const r = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${OPENAI_KEY}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [{ role: "user", content: prompt }],
        max_tokens: 300,
        temperature: 0.4,
      }),
    });

    if (!r.ok) {
      const errText = await r.text();
      console.error("OpenAI error:", r.status, errText);
      return res.status(502).json({ error: "OpenAI request failed." });
    }

    const data = await r.json();
    const explanation = data.choices?.[0]?.message?.content?.trim() || "No explanation returned.";
    res.json({ explanation });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "Server error calling OpenAI." });
  }
});

app.get("/api/health", (_req, res) => res.json({ ok: true }));

const port = process.env.PORT || 5000;
app.listen(port, () => console.log(`AI explain backend running on http://localhost:${port}`));

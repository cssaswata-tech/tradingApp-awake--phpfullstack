<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Watchlist;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class WatchlistController extends Controller
{
    // GET /api/watchlists.php -> [{ id, name, stocks:[...] }]
    public function index(Request $request)
    {
        $watchlists = $request->user()
            ->watchlists()
            ->with('stocks')
            ->orderBy('id')
            ->get();

        return response()->json($watchlists);
    }

    // POST /api/watchlists.php { name } -> created watchlist
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => ['required', 'string', 'max:255'],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'message' => $validator->errors()->first(),
                'errors' => $validator->errors(),
            ], 422);
        }

        $watchlist = $request->user()->watchlists()->create([
            'name' => $request->name,
        ]);

        return response()->json($watchlist->load('stocks'), 201);
    }

    // DELETE /api/watchlists.php?id=
    public function destroy(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'id' => ['required', 'integer'],
        ]);

        if ($validator->fails()) {
            return response()->json(['message' => 'id is required.'], 422);
        }

        $watchlist = $request->user()->watchlists()->where('id', $request->query('id'))->first();

        if (! $watchlist) {
            return response()->json(['message' => 'Watchlist not found.'], 404);
        }

        $watchlist->delete();

        return response()->json(['message' => 'Watchlist deleted.']);
    }
}
